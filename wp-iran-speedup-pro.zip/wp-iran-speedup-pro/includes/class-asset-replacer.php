<?php
/**
 * Asset Replacer Class v4.1.0
 *
 * جایگزینی منابع خارجی با نسخه‌های محلی
 * + مسدودسازی درخواست‌های خارجی (wp.com, Google Fonts, Gravatar, …)
 * + سازگاری کامل با Elementor (Editor, Preview, Frontend)
 * + پشتیبانی از WooCommerce
 *
 * @package WPISO
 * @since   4.1.0
 */

if (!defined('ABSPATH')) exit;

class WPISO_Asset_Replacer {
    private static $instance = null;

    /** @var array نقشه جایگزینی asset‌ها */
    private $asset_map = [];

    /** @var array دامنه‌های مسدود (برای بررسی سریع) */
    private $blocked_domains = [];

    /** @var string الگوی regex پیش‌ساخته دامنه‌های مسدود */
    private $blocked_domains_pattern = '';

    /**
     * لیست handle‌های محافظت‌شده المنتور — هرگز حذف نمی‌شوند
     * @var array
     */
    private $elementor_protected_handles = [
        // Core Elementor
        'elementor-frontend',
        'elementor-editor',
        'elementor-common',
        'elementor-app',
        'elementor-admin',
        'elementor-admin-bar',
        'elementor-dialog',
        'elementor-gallery',
        'elementor-waypoints',
        'elementor-webpack-runtime',
        'elementor-dev-tools',
        'elementor-common-modules',

        // Elementor Pro
        'elementor-pro',
        'elementor-pro-frontend',
        'elementor-pro-webpack-runtime',

        // Swiper (المنتور استفاده می‌کند)
        'swiper',
        'elementor-swiper',

        // Styles
        'elementor-frontend-css',
        'elementor-common-css',
        'elementor-icons',
        'elementor-icons-shared-0',
        'elementor-animations',
        'elementor-post-css',
        'elementor-global-css',
        'elementor-icons-css',
        'e-animations',

        // Widgets
        'elementor-gallery',
        'elementor-sticky',
        'elementor-motion-effects',
    ];

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->setup_asset_map();
        $this->setup_blocked_domains();
        $this->register_hooks();
    }

    /* ═══════════════════════════════════════════════════════════════
     *  تنظیمات اولیه
     * ═══════════════════════════════════════════════════════════════ */

    private function setup_asset_map() {
        $base = WPISO_URL . 'assets/';

        $this->asset_map = [

            /* ── jQuery ── */
            'jquery' => [
                'patterns' => [
                    'ajax.googleapis.com/ajax/libs/jquery',
                    'code.jquery.com/jquery',
                    'cdnjs.cloudflare.com/ajax/libs/jquery',
                    'cdn.jsdelivr.net/npm/jquery',
                ],
                'local'   => $base . 'js/jquery.min.js',
                'version' => '3.6.0',
                'type'    => 'js',
            ],

            /* ── jQuery UI ── */
            'jquery-ui' => [
                'patterns' => [
                    'code.jquery.com/ui',
                    'ajax.googleapis.com/ajax/libs/jqueryui',
                    'cdnjs.cloudflare.com/ajax/libs/jqueryui',
                ],
                'local_js'  => $base . 'js/jquery-ui.min.js',
                'local_css' => $base . 'css/jquery-ui.min.css',
                'version'   => '1.13.2',
            ],

            /* ── Bootstrap ── */
            'bootstrap' => [
                'patterns' => [
                    'maxcdn.bootstrapcdn.com/bootstrap',
                    'stackpath.bootstrapcdn.com/bootstrap',
                    'cdn.bootstrapcdn.com/bootstrap',
                    'cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap',
                    'cdn.jsdelivr.net/npm/bootstrap',
                ],
                'local_css' => $base . 'css/bootstrap.min.css',
                'local_js'  => $base . 'js/bootstrap.min.js',
                'version'   => '4.5.2',
            ],

            /* ── Font Awesome (v5) ── */
            'fontawesome' => [
                'patterns' => [
                    'use.fontawesome.com',
                    'maxcdn.bootstrapcdn.com/font-awesome',
                    'cdnjs.cloudflare.com/ajax/libs/font-awesome',
                    'cdn.jsdelivr.net/npm/@fortawesome',
                    'kit.fontawesome.com',
                    'ka-f.fontawesome.com',
                ],
                'local'   => $base . 'css/all.min.css',
                'version' => '5.15.4',
                'type'    => 'css',
            ],

            /* ── Google Fonts — مسدود ── */
            'google-fonts' => [
                'patterns' => [
                    'fonts.googleapis.com',
                    'fonts.gstatic.com',
                    'fonts.bunny.net',
                ],
                'block' => true,
            ],

            /* ── Google Analytics / Tag Manager — مسدود ── */
            'google-analytics' => [
                'patterns' => [
                    'www.google-analytics.com',
                    'ssl.google-analytics.com',
                    'www.googletagmanager.com',
                    'pagead2.googlesyndication.com',
                ],
                'block' => true,
            ],

            /*
             * ── Google Services ──
             * ⚠️ ajax.googleapis.com عمداً اینجا نیست!
             *     در بخش jquery جایگزینی محلی دارد.
             *     اگر اینجا block شود، jQuery جایگزین نمی‌شود و فقط حذف می‌شود.
             */
            'google-services' => [
                'patterns' => [
                    'maps.googleapis.com',
                    'www.gstatic.com',
                    'apis.google.com',
                ],
                'block' => true,
            ],

            /* ── WordPress.com / Jetpack — مسدود ── */
            'wp-services' => [
                'patterns' => [
                    'wp-stats.goldgate.us',          // ✅ اضافه شد — woo-tracks از اینجا لود می‌شود
                    'wp-pixel.goldgate.us',          // ✅ اضافه شد — tracking pixel
                    'wp-stats.goldgate.us',
                    'wp-pixel.goldgate.us',
                    's.w.org',
                    's0.wp.com',
                    's1.wp.com',
                    's2.wp.com',
                    'widgets.wp.com',
                    'i0.wp.com',
                    'i1.wp.com',
                    'i2.wp.com',
                    'c0.wp.com',
                    'public-api.wordpress.com',
                    'jetpack.wordpress.com',
                    'connect.wordpress.com',
                ],
                'block' => true,
            ],

            /* ── Gravatar — مسدود ── */
            'gravatar' => [
                'patterns' => [
                    'gravatar.com',
                    'secure.gravatar.com',
                    '0.gravatar.com',
                    '1.gravatar.com',
                    '2.gravatar.com',
                ],
                'block' => true,
            ],
        ];
    }

    /**
     * ساخت فهرست مسطح دامنه‌های مسدود برای بررسی سریع
     */
    private function setup_blocked_domains() {
        foreach ($this->asset_map as $config) {
            if (!empty($config['block'])) {
                foreach ($config['patterns'] as $pattern) {
                    $this->blocked_domains[] = $pattern;
                }
            }
        }
        // ✅ پیش‌ساخت الگوی regex برای استفاده در output buffer (بهینه‌سازی عملکرد)
        if (!empty($this->blocked_domains)) {
            $this->blocked_domains_pattern = implode('|', array_map(function($d) {
                return preg_quote($d, '#');
            }, $this->blocked_domains));
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  تشخیص وضعیت المنتور
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * آیا الان در حالت ویرایشگر المنتور هستیم؟
     * شامل: editor, preview, و iframe المنتور
     */
    private function is_elementor_mode() {
        // Elementor Editor
        if (isset($_GET['action']) && $_GET['action'] === 'elementor') {
            return true;
        }

        // Elementor Preview
        if (isset($_GET['elementor-preview'])) {
            return true;
        }

        // Elementor iframe
        if (isset($_GET['elementor_library'])) {
            return true;
        }

        // بررسی از طریق کلاس المنتور
        if (class_exists('\Elementor\Plugin')) {
            $elementor = \Elementor\Plugin::$instance;
            if ($elementor && isset($elementor->editor) && method_exists($elementor->editor, 'is_edit_mode') && $elementor->editor->is_edit_mode()) {
                return true;
            }
            if ($elementor && isset($elementor->preview) && method_exists($elementor->preview, 'is_preview_mode') && $elementor->preview->is_preview_mode()) {
                return true;
            }
        }

        return false;
    }

    /**
     * آیا handle متعلق به المنتور است و باید محافظت شود؟
     */
    private function is_elementor_handle($handle) {
        if (in_array($handle, $this->elementor_protected_handles, true)) {
            return true;
        }

        // بررسی پترن نام
        if (
            strpos($handle, 'elementor') !== false ||
            strpos($handle, 'e-') === 0
        ) {
            return true;
        }

        return false;
    }

    /**
     * آیا URL متعلق به فایل‌های محلی پلاگین المنتور است؟
     */
    private function is_local_plugin_url($url) {
        if (empty($url)) return false;

        // URL نسبی = محلی
        if (strpos($url, '//') === false) return true;

        // بررسی host
        $site_host = parse_url(home_url(), PHP_URL_HOST);
        $url_host  = parse_url($url, PHP_URL_HOST);

        if (empty($url_host) || $url_host === $site_host) {
            return true;
        }

        return false;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  ثبت هوک‌ها
     * ═══════════════════════════════════════════════════════════════ */

    private function register_hooks() {

        /* ── جایگزینی asset‌ها ── */
        add_action('wp_enqueue_scripts',    [$this, 'replace_registered_assets'], 1);
        add_action('admin_enqueue_scripts', [$this, 'replace_registered_assets'], 1);

        /* ── حذف asset‌های خارجی ── */
        add_action('wp_enqueue_scripts',    [$this, 'dequeue_external_assets'], 9999);
        add_action('admin_enqueue_scripts', [$this, 'dequeue_external_assets'], 9999);

        /* ── فیلتر URL هر asset ── */
        add_filter('style_loader_src',  [$this, 'filter_asset_url'], 9999, 2);
        add_filter('script_loader_src', [$this, 'filter_asset_url'], 9999, 2);

        /* ── محتوا و ویجت‌ها ── */
        add_filter('the_content',  [$this, 'replace_content_urls'], 9999);
        add_filter('widget_text',  [$this, 'replace_content_urls'], 9999);

        /* ── Output Buffer ── */
        add_action('template_redirect', [$this, 'start_output_buffer'], 0);

        /* ── مسدودسازی HTTP سمت سرور ── */
        add_filter('pre_http_request', [$this, 'block_external_http'], 10, 3);

        /* ── حذف Stats / Jetpack ── */
        add_action('wp_head',   [$this, 'remove_stats_actions'], 0);
        add_action('wp_footer', [$this, 'remove_stats_actions'], 0);

        /* ── Elementor: فقط حذف Google Fonts ── */
        add_filter('elementor/frontend/print_google_fonts', '__return_false');

        add_action('elementor/frontend/after_register_styles', function() {
            // فقط google-fonts handle‌ها حذف شوند — نه eicons و نه سایر استایل‌های المنتور
            global $wp_styles;
            if (empty($wp_styles->registered)) return;
            foreach ($wp_styles->registered as $handle => $style) {
                if (
                    strpos($handle, 'google-fonts') !== false &&
                    !empty($style->src) &&
                    (
                        strpos($style->src, 'fonts.googleapis.com') !== false ||
                        strpos($style->src, 'fonts.bunny.net') !== false
                    )
                ) {
                    wp_dequeue_style($handle);
                    wp_deregister_style($handle);
                }
            }
        }, 999);

        /* ── WooCommerce — اولویت بالا برای اطمینان از حذف woo-tracks ── */
        add_action('wp_enqueue_scripts', [$this, 'replace_woocommerce_assets'], 9998);
        add_action('admin_enqueue_scripts', [$this, 'replace_woocommerce_assets'], 9998);

        /* ── Gravatar ── */
        add_filter('get_avatar_url',  [$this, 'replace_gravatar_url'], 9999, 3);
        add_filter('get_avatar',      [$this, 'replace_gravatar_html'], 9999, 6);

        /* ── DNS Prefetch ── */
        add_filter('wp_resource_hints', [$this, 'remove_external_hints'], 9999, 2);
        remove_action('wp_head', 'wp_resource_hints', 2);

        /* ── Google Fonts — مسدودسازی کامل در تمام مراحل ── */
        add_action('wp_enqueue_scripts', [$this, 'dequeue_google_fonts'], 9999);
        add_action('admin_enqueue_scripts', [$this, 'dequeue_google_fonts'], 9999);
        // ✅ مرحله آخر قبل از رندر — برخی قالب‌ها دیرهنگام Google Fonts را اضافه می‌کنند
        add_action('wp_print_styles', [$this, 'dequeue_google_fonts'], 9999);
        add_action('admin_print_styles', [$this, 'dequeue_google_fonts'], 9999);
    }

    /* ═══════════════════════════════════════════════════════════════
     *  جایگزینی Asset‌های ثبت‌شده وردپرس
     * ═══════════════════════════════════════════════════════════════ */

    public function replace_registered_assets() {

        /* ── jQuery ── */
        wp_deregister_script('jquery-core');
        wp_deregister_script('jquery');
        wp_register_script(
            'jquery-core',
            $this->asset_map['jquery']['local'],
            [],
            $this->asset_map['jquery']['version'],
            false
        );
        wp_register_script('jquery', false, ['jquery-core'], $this->asset_map['jquery']['version']);
        wp_enqueue_script('jquery');

        /* ── jQuery UI ── */
        wp_deregister_script('jquery-ui-core');
        wp_register_script(
            'jquery-ui-core',
            $this->asset_map['jquery-ui']['local_js'],
            ['jquery'],
            $this->asset_map['jquery-ui']['version'],
            true
        );
        wp_deregister_style('jquery-ui');
        wp_register_style(
            'jquery-ui',
            $this->asset_map['jquery-ui']['local_css'],
            [],
            $this->asset_map['jquery-ui']['version']
        );

        /* ── Bootstrap (شرطی) ── */
        $this->conditionally_replace_style('bootstrap', $this->asset_map['bootstrap']);
        $this->conditionally_replace_script('bootstrap', $this->asset_map['bootstrap'], ['jquery']);

        /* ── Font Awesome — فقط handle‌های FA خالص، نه eicons المنتور ── */
        /* ✅ اصلاح: فقط اگر سایت واقعاً از FA استفاده می‌کند جایگزین شود */
        $settings = get_option('wpiso_settings', []);
        $fa_handles = [
            'font-awesome', 'fontawesome', 'fontawesome-all',
            'fa', 'fa-all', 'fa-brands', 'fa-solid', 'fa-regular',
        ];
        $fa_was_used = false;
        foreach ($fa_handles as $handle) {
            if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
                $fa_was_used = true;
                wp_dequeue_style($handle);
                wp_deregister_style($handle);
            }
        }
        if ($fa_was_used && !empty($settings['replace_fontawesome'])) {
            wp_register_style(
                'fontawesome-local',
                $this->asset_map['fontawesome']['local'],
                [],
                $this->asset_map['fontawesome']['version']
            );
            wp_enqueue_style('fontawesome-local');
        }

        /* ── Jetpack / Stats ── */
        $stats_handles = [
            'jetpack-stats', 'wp-stats', 'stats',
            'jetpack_tracks', 'jp-tracks', 'jetpack-jitm',
            'jetpack-connection',
        ];
        foreach ($stats_handles as $handle) {
            wp_dequeue_script($handle);
            wp_deregister_script($handle);
        }

        /*
         * ── WooCommerce Tracking (wc-tracks / woo-tracks) ──
         * ⚠️ نباید deregister شوند! ده‌ها اسکریپت ادمین ووکامرس به wc-tracks وابسته‌اند.
         *    اگر حذف شود → زنجیره Missing Dependencies شکسته می‌شود.
         * ✅ راه‌حل: جایگزینی با اسکریپت خالی محلی — handle باقی می‌ماند، درخواست خارجی نمی‌رود.
         */
        $this->stub_tracking_script('wc-tracks');
        $this->stub_tracking_script('woo-tracks');
    }

    private function conditionally_replace_style($handle, $config) {
        if (wp_style_is($handle, 'registered') || wp_style_is($handle, 'enqueued')) {
            $was_enqueued = wp_style_is($handle, 'enqueued');
            wp_dequeue_style($handle);
            wp_deregister_style($handle);
            wp_register_style($handle, $config['local_css'], [], $config['version']);
            if ($was_enqueued) wp_enqueue_style($handle);
        }
    }

    private function conditionally_replace_script($handle, $config, $deps = []) {
        if (wp_script_is($handle, 'registered') || wp_script_is($handle, 'enqueued')) {
            $was_enqueued = wp_script_is($handle, 'enqueued');
            wp_dequeue_script($handle);
            wp_deregister_script($handle);
            wp_register_script($handle, $config['local_js'], $deps, $config['version'], true);
            if ($was_enqueued) wp_enqueue_script($handle);
        }
    }

    /**
     * جایگزینی اسکریپت tracking با یک stub خالی
     * handle حفظ می‌شود (زنجیره وابستگی سالم می‌ماند) ولی هیچ کد خارجی لود نمی‌شود
     *
     * @param string $handle نام handle اسکریپت
     */
    private function stub_tracking_script($handle) {
        if (wp_script_is($handle, 'registered') || wp_script_is($handle, 'enqueued')) {
            $was_enqueued = wp_script_is($handle, 'enqueued');
            wp_dequeue_script($handle);
            wp_deregister_script($handle);
        }
        // ثبت مجدد بدون فایل — فقط یک inline script خالی
        wp_register_script($handle, false, [], WPISO_VERSION, true);
        wp_add_inline_script($handle, '/* WPISO: tracking disabled */');
    }

    /* ═══════════════════════════════════════════════════════════════
     *  فیلتر URL — با محافظت کامل المنتور
     * ═══════════════════════════════════════════════════════════════ */

    public function filter_asset_url($src, $handle = '') {
        if (empty($src) || !is_string($src)) {
            return $src;
        }

        // ✅ محافظت المنتور: هرگز URL المنتور را تغییر نده
        if ($this->is_elementor_handle($handle)) {
            return $src;
        }

        // ✅ محافظت: URL محلی پلاگین‌ها دستکاری نشود
        if ($this->is_local_plugin_url($src)) {
            return $src;
        }

        foreach ($this->asset_map as $config) {
            if (empty($config['patterns'])) continue;

            foreach ($config['patterns'] as $pattern) {
                if (strpos($src, $pattern) === false) continue;

                if (!empty($config['block'])) {
                    return '';
                }

                if (isset($config['local_css']) && $this->is_css_url($src)) {
                    return $config['local_css'];
                }
                if (isset($config['local_js']) && $this->is_js_url($src)) {
                    return $config['local_js'];
                }
                if (isset($config['local'])) {
                    return $config['local'];
                }

                break;
            }
        }

        return $src;
    }

    private function is_css_url($url) {
        $path = strtolower(parse_url($url, PHP_URL_PATH) ?: '');
        return (strpos($path, '.css') !== false);
    }

    private function is_js_url($url) {
        $path = strtolower(parse_url($url, PHP_URL_PATH) ?: '');
        return (strpos($path, '.js') !== false);
    }

    /* ═══════════════════════════════════════════════════════════════
     *  حذف Google Fonts از صف
     * ═══════════════════════════════════════════════════════════════ */

    public function dequeue_google_fonts() {
        global $wp_styles, $wp_scripts;

        // ✅ حذف تمام استایل‌هایی که به Google Fonts اشاره دارند
        if (!empty($wp_styles->registered)) {
            foreach ($wp_styles->registered as $handle => $style) {
                if (empty($style->src)) continue;
                if (
                    strpos($style->src, 'fonts.googleapis.com') !== false ||
                    strpos($style->src, 'fonts.gstatic.com')    !== false ||
                    strpos($style->src, 'fonts.bunny.net')      !== false
                ) {
                    wp_dequeue_style($handle);
                    wp_deregister_style($handle);
                }
            }
        }

        // ✅ حذف اسکریپت‌هایی که Google Fonts را به صورت JS لود می‌کنند (WebFont Loader)
        if (!empty($wp_scripts->registered)) {
            foreach ($wp_scripts->registered as $handle => $script) {
                if (empty($script->src)) continue;
                if (
                    strpos($script->src, 'fonts.googleapis.com') !== false ||
                    strpos($script->src, 'webfont')              !== false
                ) {
                    wp_dequeue_script($handle);
                    wp_deregister_script($handle);
                }
            }
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  حذف asset‌های خارجی — با محافظت المنتور
     * ═══════════════════════════════════════════════════════════════ */

    public function dequeue_external_assets() {
        global $wp_scripts, $wp_styles;

        if (!empty($wp_scripts->registered)) {
            foreach ($wp_scripts->registered as $handle => $script) {
                // ✅ محافظت المنتور
                if ($this->is_elementor_handle($handle)) continue;

                if (!empty($script->src) && $this->is_blocked_url($script->src)) {
                    // ✅ URL محلی دستکاری نشود
                    if ($this->is_local_plugin_url($script->src)) continue;

                    wp_dequeue_script($handle);
                    wp_deregister_script($handle);
                }
            }
        }

        if (!empty($wp_styles->registered)) {
            foreach ($wp_styles->registered as $handle => $style) {
                // ✅ محافظت المنتور
                if ($this->is_elementor_handle($handle)) continue;

                if (!empty($style->src) && $this->is_blocked_url($style->src)) {
                    // ✅ URL محلی دستکاری نشود
                    if ($this->is_local_plugin_url($style->src)) continue;

                    wp_dequeue_style($handle);
                    wp_deregister_style($handle);
                }
            }
        }
    }

    private function is_blocked_url($url) {
        if (empty($url)) return false;
        foreach ($this->blocked_domains as $domain) {
            if (strpos($url, $domain) !== false) {
                return true;
            }
        }
        return false;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  جایگزینی URL‌ها در محتوا
     * ═══════════════════════════════════════════════════════════════ */

    public function replace_content_urls($content) {
        if (empty($content) || !is_string($content)) return $content;

        // ✅ در حالت المنتور محتوا را تغییر نده
        if ($this->is_elementor_mode()) return $content;

        foreach ($this->asset_map as $config) {
            if (empty($config['patterns'])) continue;

            foreach ($config['patterns'] as $pattern) {
                $escaped = preg_quote($pattern, '#');

                if (!empty($config['block'])) {
                    $content = preg_replace(
                        '#<script[^>]*' . $escaped . '[^>]*>.*?</script>#is',
                        '', $content
                    );
                    $content = preg_replace(
                        '#<link[^>]*' . $escaped . '[^>]*/?\s*>#is',
                        '', $content
                    );
                    continue;
                }

                $local = $config['local'] ?? $config['local_css'] ?? $config['local_js'] ?? '';
                if ($local) {
                    $content = preg_replace(
                        '#https?://[^\s"\'<>]*' . $escaped . '[^\s"\'<>]*#i',
                        $local, $content
                    );
                }
            }
        }

        return $content;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  Output Buffer
     *  ✅ غیرفعال: ادمین، AJAX، Cron، REST، المنتور، سایر بیلدرها
     * ═══════════════════════════════════════════════════════════════ */

    public function start_output_buffer() {
        if (is_admin()) return;
        if (wp_doing_ajax()) return;
        if (wp_doing_cron()) return;
        if (defined('REST_REQUEST') && REST_REQUEST) return;
        if (defined('XMLRPC_REQUEST') && XMLRPC_REQUEST) return;

        // ✅ المنتور ادیتور و پریویو
        if ($this->is_elementor_mode()) return;

        // ✅ سایر پیج‌بیلدرها
        if (isset($_GET['preview'])) return;
        if (isset($_GET['customize_changeset_uuid'])) return;
        if (isset($_GET['brizy-edit'])) return;
        if (isset($_GET['ct_builder'])) return;
        if (isset($_GET['fl_builder'])) return;
        if (isset($_GET['vcv-action'])) return;

        ob_start([$this, 'filter_final_html']);
    }

    public function filter_final_html($html) {
        if (empty($html) || strlen($html) < 100) return $html;

        // ✅ بررسی مجدد: HTML المنتور ادیتور
        if (
            strpos($html, 'elementor-edit-mode') !== false ||
            strpos($html, 'elementor-editor-active') !== false ||
            strpos($html, 'elementor-preview') !== false
        ) {
            return $html;
        }

        $remove_patterns = [
            '#<script[^>]*stats\.wp\.com[^>]*>.*?</script>#is',
            '#<script[^>]*pixel\.wp\.com[^>]*>.*?</script>#is',
            '#<script[^>]*>\s*var\s+_stq\s*=.*?</script>#is',
            '#<script[^>]*>.*?new\s+Image\(\)\.src\s*=\s*["\'][^"\']*stats\.wp\.com[^"\']*["\'].*?</script>#is',
            '#<(?:img|noscript)[^>]*(?:pixel|stats)\.wp\.com[^>]*(?:/>|>(?:.*?</noscript>)?)#is',

            '#<link[^>]*(?:dns-prefetch|preconnect)[^>]*(?:' . $this->blocked_domains_pattern . ')[^>]*/?\s*>#is',

            '#<link[^>]*fonts\.googleapis\.com[^>]*/?\s*>#is',
            '#<link[^>]*fonts\.gstatic\.com[^>]*/?\s*>#is',
            '#<link[^>]*fonts\.bunny\.net[^>]*/?\s*>#is',

            '#<script[^>]*google-analytics\.com[^>]*>.*?</script>#is',
            '#<script[^>]*googletagmanager\.com[^>]*>.*?</script>#is',

            // ✅ الگوی gtag|ga حذف شد — خیلی عمومی بود و المنتور gallery را خراب می‌کرد

            '#<style[^>]*id=["\']google-fonts-[0-9]*["\'][^>]*>.*?</style>#is',
            '#<(?:link|script)[^>]*[isc]\d\.wp\.com[^>]*(?:/>|>(?:.*?</script>)?)#is',
        ];

        foreach ($remove_patterns as $pattern) {
            $html = preg_replace($pattern, '', $html);
        }

        $html = $this->fix_fontawesome_paths($html);
        $html = $this->remove_inline_google_fonts($html);
        $html = preg_replace('/\n{3,}/', "\n\n", $html);

        return $html;
    }

    private function fix_fontawesome_paths($html) {
        $webfonts_url = WPISO_URL . 'assets/webfonts/';
        $cdn_patterns = [
            '#https?://[^\s"\'<>]*cdnjs\.cloudflare\.com/ajax/libs/font-awesome/[^/]*/webfonts/#i',
            '#https?://[^\s"\'<>]*use\.fontawesome\.com/releases/v[^/]*/webfonts/#i',
            '#https?://[^\s"\'<>]*cdn\.jsdelivr\.net/npm/@fortawesome/[^/]*/webfonts/#i',
            '#https?://[^\s"\'<>]*maxcdn\.bootstrapcdn\.com/font-awesome/[^/]*/fonts/#i',
            '#https?://[^\s"\'<>]*ka-f\.fontawesome\.com/releases/v[^/]*/webfonts/#i',
        ];
        foreach ($cdn_patterns as $pattern) {
            $html = preg_replace($pattern, $webfonts_url, $html);
        }
        return $html;
    }

    private function remove_inline_google_fonts($html) {
        $html = preg_replace(
            '#@import\s+url\(["\']?https?://fonts\.googleapis\.com[^)]*\)["\']?\s*;?#i',
            '', $html
        );
        $html = preg_replace(
            '#@import\s+url\(["\']?https?://fonts\.bunny\.net[^)]*\)["\']?\s*;?#i',
            '', $html
        );
        return $html;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  مسدودسازی HTTP سمت سرور — با محافظت سایت خودی
     * ═══════════════════════════════════════════════════════════════ */

    public function block_external_http($preempt, $args, $url) {
        if (!is_string($url) || empty($url)) return $preempt;

        $host = parse_url($url, PHP_URL_HOST);
        if (empty($host)) return $preempt;

        // ✅ سایت خودمان همیشه مجاز
        $site_host = parse_url(home_url(), PHP_URL_HOST);
        if ($host === $site_host) return $preempt;

        foreach ($this->blocked_domains as $blocked) {
            if ($host === $blocked || fnmatch('*.' . $blocked, $host)) {
                return new WP_Error(
                    'wpiso_blocked',
                    sprintf('[WPISO] درخواست به %s مسدود شد.', esc_html($host))
                );
            }
        }

        return $preempt;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  Stats / Jetpack
     * ═══════════════════════════════════════════════════════════════ */

    public function remove_stats_actions() {
        remove_action('wp_head',   'stats_header', 20);
        remove_action('wp_footer', 'stats_footer', 101);
        remove_action('wp_head',   'stats_add_shutdown_action');
        remove_action('wp_footer', 'stats_add_shutdown_action');

        if (class_exists('Jetpack')) {
            remove_action('wp_head', ['Jetpack', 'dns_prefetch']);
            remove_action('wp_head', 'jetpack_og_tags');
        }
        if (class_exists('Automattic\\Jetpack\\Stats\\Main')) {
            remove_action('wp_footer', ['Automattic\\Jetpack\\Stats\\Main', 'add_stats_pixel']);
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  WooCommerce
     * ═══════════════════════════════════════════════════════════════ */

    public function replace_woocommerce_assets() {
        if (!class_exists('WooCommerce')) return;

        // اسکریپت‌هایی که وابسته‌ای ندارند — حذف کامل بی‌خطر
        $wc_safe_to_remove = [
            'wc-blocks-google-analytics',
            'google-recaptcha',
        ];
        foreach ($wc_safe_to_remove as $handle) {
            wp_dequeue_script($handle);
            wp_deregister_script($handle);
        }

        // ✅ wc-tracks / woo-tracks — stub بزن نه حذف (وابسته‌های زیادی دارند)
        $this->stub_tracking_script('wc-tracks');
        $this->stub_tracking_script('woo-tracks');
        $this->stub_tracking_script('woocommerce-tracks');

        // ✅ بررسی اسکریپت‌هایی که src آن‌ها به wp-stats.goldgate.us اشاره دارد
        // فقط src را خالی کن، handle را حذف نکن
        global $wp_scripts;
        if (!empty($wp_scripts->registered)) {
            foreach ($wp_scripts->registered as $handle => $script) {
                if (
                    !empty($script->src) &&
                    (strpos($script->src, 'wp-stats.goldgate.us') !== false ||
                     strpos($script->src, 'wp-pixel.goldgate.us') !== false) &&
                    !$this->is_local_plugin_url($script->src)
                ) {
                    // src را خالی کن بجای حذف handle — زنجیره وابستگی حفظ شود
                    $wp_scripts->registered[$handle]->src = false;
                }
            }
        }

        global $wp_styles;
        if (!empty($wp_styles->registered)) {
            foreach ($wp_styles->registered as $handle => $style) {
                if (
                    strpos($handle, 'wc-') === 0 &&
                    !empty($style->src) &&
                    $this->is_blocked_url($style->src) &&
                    !$this->is_local_plugin_url($style->src)
                ) {
                    wp_dequeue_style($handle);
                }
            }
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  Gravatar
     * ═══════════════════════════════════════════════════════════════ */

    public function replace_gravatar_url($url, $id_or_email = null, $args = []) {
        if (empty($url)) return $url;
        if (strpos($url, 'gravatar.com') !== false) {
            return $this->get_default_avatar_url();
        }
        return $url;
    }

    public function replace_gravatar_html($avatar, $id_or_email = null, $size = 96, $default = '', $alt = '', $args = []) {
        if (is_string($avatar) && strpos($avatar, 'gravatar.com') !== false) {
            $safe_alt = esc_attr($alt);
            $url = esc_url($this->get_default_avatar_url());
            return sprintf(
                '<img alt="%s" src="%s" class="avatar avatar-%d photo avatar-default" height="%d" width="%d" loading="lazy" />',
                $safe_alt, $url, (int)$size, (int)$size, (int)$size
            );
        }
        return $avatar;
    }

    private function get_default_avatar_url() {
        $local_avatar = WPISO_PATH . 'assets/img/default-avatar.svg';
        if (file_exists($local_avatar)) {
            return WPISO_URL . 'assets/img/default-avatar.svg';
        }
        return includes_url('images/blank.gif');
    }

    /* ═══════════════════════════════════════════════════════════════
     *  DNS Prefetch / Preconnect
     * ═══════════════════════════════════════════════════════════════ */

    public function remove_external_hints($urls, $relation_type) {
        if (in_array($relation_type, ['dns-prefetch', 'preconnect'], true)) {
            foreach ($urls as $key => $url) {
                $host = is_array($url) ? ($url['href'] ?? '') : $url;
                if ($this->is_blocked_url($host)) {
                    unset($urls[$key]);
                }
            }
        }
        return array_values($urls);
    }
}
