<?php
/**
 * Core Class — بوت‌استرپ اصلی افزونه
 *
 * @package WPISO
 * @since   4.0.0
 */

if (!defined('ABSPATH')) exit;

class WPISO_Core {
    private static $instance = null;

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }

    private function load_dependencies() {
        require_once WPISO_PATH . 'includes/class-asset-replacer.php';
        require_once WPISO_PATH . 'includes/class-performance-optimizer.php';
        require_once WPISO_PATH . 'includes/class-font-manager.php';
        require_once WPISO_PATH . 'includes/class-domain-manager.php';
        require_once WPISO_PATH . 'includes/class-admin-settings.php';
    }

    private function init_hooks() {
        WPISO_Asset_Replacer::init();
        WPISO_Performance_Optimizer::init();
        WPISO_Font_Manager::init();
        WPISO_Domain_Manager::init();
        WPISO_Admin_Settings::init();

        // AJAX handlers
        add_action('wp_ajax_wpiso_save_settings', [$this, 'ajax_save_settings']);
        add_action('wp_ajax_wpiso_test_domain',   [$this, 'ajax_test_domain']);
        add_action('wp_ajax_wpiso_upload_font',    [$this, 'ajax_upload_font']);
        add_action('wp_ajax_wpiso_delete_font',    [$this, 'ajax_delete_font']);
        add_action('wp_ajax_wpiso_export_settings',[$this, 'ajax_export_settings']);
        add_action('wp_ajax_wpiso_import_settings',[$this, 'ajax_import_settings']);
    }

    /* ───── فعال‌سازی / غیرفعال‌سازی ───── */

    public static function activate() {
        update_option('wpiso_version', WPISO_VERSION);

        // تنظیمات پیش‌فرض
        if (false === get_option('wpiso_settings')) {
            update_option('wpiso_settings', self::get_default_settings());
        }
        if (false === get_option('wpiso_custom_blocked_domains')) {
            update_option('wpiso_custom_blocked_domains', []);
        }
        if (false === get_option('wpiso_whitelisted_domains')) {
            update_option('wpiso_whitelisted_domains', []);
        }
        if (false === get_option('wpiso_custom_fonts')) {
            update_option('wpiso_custom_fonts', []);
        }

        // ساخت پوشه فونت‌های سفارشی
        $upload_dir = wp_upload_dir();
        $font_dir = $upload_dir['basedir'] . '/wpiso-fonts';
        if (!file_exists($font_dir)) {
            wp_mkdir_p($font_dir);
            // htaccess برای دسترسی مستقیم
            file_put_contents($font_dir . '/.htaccess', "Options -Indexes\n<FilesMatch \"\.(woff2?|ttf|otf|eot|svg)$\">\n    Header set Access-Control-Allow-Origin \"*\"\n</FilesMatch>");
        }

        flush_rewrite_rules();
    }

    public static function deactivate() {
        delete_transient('wpiso_status_cache');
        delete_transient('wpiso_domain_test_cache');
        flush_rewrite_rules();
    }

    public static function get_default_settings() {
        return [
            // مسدودسازی سرویس‌ها
            'block_google_fonts'      => 1,
            'block_gravatar'          => 1,
            'block_wp_stats'          => 1,
            'block_google_analytics'  => 1,
            'block_google_services'   => 1,
            'block_wp_services'       => 1,
            'block_jetpack'           => 1,
            'block_elementor_ext'     => 1,

            // جایگزینی‌ها
            'replace_jquery'          => 1,
            'replace_fontawesome'     => 1,

            // بهینه‌سازی
            'disable_heartbeat'       => 1,
            'disable_embeds'          => 1,
            'disable_emoji'           => 1,
            'disable_xmlrpc'          => 1,
            'disable_rss'             => 0,
            'limit_revisions'         => 1,
            'optimize_updates'        => 1,

            // فونت
            'custom_font_enabled'     => 0,
            'custom_font_name'        => '',
            'custom_font_target'      => 'body', // body, headings, both
            'custom_font_weight'      => '400',
            'font_display'            => 'swap',

            // فیلترینگ پیشرفته
            'domain_filter_mode'      => 'blacklist', // blacklist | whitelist
            'block_all_external'      => 0,
            'log_blocked_requests'    => 0,
        ];
    }

    /* ───── AJAX Handlers ───── */

    public function ajax_save_settings() {
        check_ajax_referer('wpiso_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی ندارید.');
        }

        $settings = [];
        $defaults = self::get_default_settings();
        foreach ($defaults as $key => $default) {
            if (is_int($default)) {
                $settings[$key] = isset($_POST[$key]) ? 1 : 0;
            } else {
                $settings[$key] = sanitize_text_field($_POST[$key] ?? $default);
            }
        }

        // ذخیره دامنه‌های سفارشی مسدود
        if (isset($_POST['custom_blocked_domains'])) {
            $domains = $this->sanitize_domain_list($_POST['custom_blocked_domains']);
            update_option('wpiso_custom_blocked_domains', $domains);
        }

        // ذخیره وایت‌لیست
        if (isset($_POST['whitelisted_domains'])) {
            $domains = $this->sanitize_domain_list($_POST['whitelisted_domains']);
            update_option('wpiso_whitelisted_domains', $domains);
        }

        update_option('wpiso_settings', $settings);
        delete_transient('wpiso_status_cache');

        wp_send_json_success('تنظیمات ذخیره شد.');
    }

    private function sanitize_domain_list($input) {
        if (!is_string($input)) return [];
        $lines = explode("\n", $input);
        $domains = [];
        foreach ($lines as $line) {
            $domain = trim(strtolower($line));
            $domain = preg_replace('#^https?://#', '', $domain);
            $domain = rtrim($domain, '/');
            if (!empty($domain) && preg_match('/^[a-z0-9]([a-z0-9\-\.]*[a-z0-9])?(\.[a-z]{2,})+$/i', $domain)) {
                $domains[] = $domain;
            }
        }
        return array_unique($domains);
    }

    public function ajax_test_domain() {
        check_ajax_referer('wpiso_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی ندارید.');
        }

        $domain = sanitize_text_field($_POST['domain'] ?? '');
        if (empty($domain)) {
            wp_send_json_error('دامنه وارد نشده.');
        }

        $url = 'https://' . $domain;
        $start = microtime(true);
        $response = wp_remote_head($url, ['timeout' => 10, 'sslverify' => false]);
        $elapsed = round((microtime(true) - $start) * 1000);

        if (is_wp_error($response)) {
            wp_send_json_success([
                'reachable' => false,
                'time'      => $elapsed,
                'error'     => $response->get_error_message(),
            ]);
        } else {
            wp_send_json_success([
                'reachable' => true,
                'time'      => $elapsed,
                'code'      => wp_remote_retrieve_response_code($response),
            ]);
        }
    }

    public function ajax_upload_font() {
        check_ajax_referer('wpiso_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی ندارید.');
        }

        if (empty($_FILES['font_file'])) {
            wp_send_json_error('فایل فونت انتخاب نشده.');
        }

        $allowed_types = ['woff', 'woff2', 'ttf', 'otf', 'eot'];
        $file = $_FILES['font_file'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed_types)) {
            wp_send_json_error('فرمت فایل مجاز نیست. فرمت‌های مجاز: ' . implode(', ', $allowed_types));
        }

        $font_name = sanitize_text_field($_POST['font_name'] ?? '');
        $font_weight = sanitize_text_field($_POST['font_weight'] ?? '400');
        $font_style = sanitize_text_field($_POST['font_style'] ?? 'normal');

        if (empty($font_name)) {
            wp_send_json_error('نام فونت را وارد کنید.');
        }

        $upload_dir = wp_upload_dir();
        $font_dir = $upload_dir['basedir'] . '/wpiso-fonts';
        if (!file_exists($font_dir)) {
            wp_mkdir_p($font_dir);
        }

        $safe_name = sanitize_file_name($font_name . '-' . $font_weight . '-' . $font_style . '.' . $ext);
        $dest = $font_dir . '/' . $safe_name;

        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            wp_send_json_error('خطا در آپلود فایل.');
        }

        // ذخیره اطلاعات فونت
        $fonts = get_option('wpiso_custom_fonts', []);
        $font_id = 'font_' . md5($font_name . $font_weight . $font_style);
        $fonts[$font_id] = [
            'name'     => $font_name,
            'weight'   => $font_weight,
            'style'    => $font_style,
            'file'     => $safe_name,
            'format'   => $ext,
            'url'      => $upload_dir['baseurl'] . '/wpiso-fonts/' . $safe_name,
            'uploaded' => current_time('mysql'),
        ];
        update_option('wpiso_custom_fonts', $fonts);

        wp_send_json_success([
            'message' => 'فونت با موفقیت آپلود شد.',
            'font'    => $fonts[$font_id],
            'font_id' => $font_id,
        ]);
    }

    public function ajax_delete_font() {
        check_ajax_referer('wpiso_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی ندارید.');
        }

        $font_id = sanitize_text_field($_POST['font_id'] ?? '');
        $fonts = get_option('wpiso_custom_fonts', []);

        if (!isset($fonts[$font_id])) {
            wp_send_json_error('فونت یافت نشد.');
        }

        // حذف فایل
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['basedir'] . '/wpiso-fonts/' . $fonts[$font_id]['file'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }

        unset($fonts[$font_id]);
        update_option('wpiso_custom_fonts', $fonts);

        wp_send_json_success('فونت حذف شد.');
    }

    public function ajax_export_settings() {
        check_ajax_referer('wpiso_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی ندارید.');
        }

        $export = [
            'version'          => WPISO_VERSION,
            'settings'         => get_option('wpiso_settings', []),
            'blocked_domains'  => get_option('wpiso_custom_blocked_domains', []),
            'whitelisted'      => get_option('wpiso_whitelisted_domains', []),
            'fonts'            => get_option('wpiso_custom_fonts', []),
            'exported_at'      => current_time('mysql'),
        ];

        wp_send_json_success($export);
    }

    public function ajax_import_settings() {
        check_ajax_referer('wpiso_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی ندارید.');
        }

        $json = stripslashes($_POST['import_data'] ?? '');
        $data = json_decode($json, true);

        if (!$data || !isset($data['settings'])) {
            wp_send_json_error('فرمت فایل نامعتبر است.');
        }

        if (isset($data['settings'])) {
            update_option('wpiso_settings', $data['settings']);
        }
        if (isset($data['blocked_domains'])) {
            update_option('wpiso_custom_blocked_domains', $data['blocked_domains']);
        }
        if (isset($data['whitelisted'])) {
            update_option('wpiso_whitelisted_domains', $data['whitelisted']);
        }

        delete_transient('wpiso_status_cache');
        wp_send_json_success('تنظیمات با موفقیت وارد شد.');
    }
}
