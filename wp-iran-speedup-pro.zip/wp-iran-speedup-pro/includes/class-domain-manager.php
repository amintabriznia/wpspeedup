<?php
/**
 * Domain Manager v4.0.0
 *
 * مدیریت وایت‌لیست و بلک‌لیست دامنه‌ها
 * فیلترینگ پیشرفته برای شرایط ایران
 *
 * @package WPISO
 * @since   4.0.0
 */

if (!defined('ABSPATH')) exit;

class WPISO_Domain_Manager {
    private static $instance = null;

    /** @var array لیست پیش‌فرض دامنه‌های مسدود (ایران) */
    private $default_blocked = [];

    /** @var array دامنه‌های مجاز (وایت‌لیست) */
    private $whitelisted = [];

    /** @var array دامنه‌های سفارشی مسدود (بلک‌لیست) */
    private $custom_blocked = [];

    /** @var string حالت فیلتر: blacklist | whitelist */
    private $filter_mode = 'blacklist';

    /** @var array لاگ درخواست‌های مسدود */
    private $request_log = [];

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_settings();
        $this->register_hooks();
    }

    private function load_settings() {
        $settings = get_option('wpiso_settings', []);

        $this->filter_mode = $settings['domain_filter_mode'] ?? 'blacklist';

        // دامنه‌های پیش‌فرض مسدود
        $this->default_blocked = $this->get_iran_blocked_defaults();

        // دامنه‌های سفارشی مسدود
        $this->custom_blocked = get_option('wpiso_custom_blocked_domains', []);

        // وایت‌لیست
        $this->whitelisted = get_option('wpiso_whitelisted_domains', []);

        // اضافه کردن وایت‌لیست پیش‌فرض (دامنه‌های ضروری)
        $this->whitelisted = array_merge($this->get_essential_whitelist(), $this->whitelisted);
    }

    /**
     * دامنه‌های پیش‌فرض مسدود برای ایران
     */
    private function get_iran_blocked_defaults() {
        $settings = get_option('wpiso_settings', []);
        $blocked = [];

        // Google Fonts
        if (!empty($settings['block_google_fonts'])) {
            $blocked = array_merge($blocked, [
                'fonts.googleapis.com',
                'fonts.gstatic.com',
                'fonts.bunny.net',
            ]);
        }

        // Google Services
        // ⚠️ ajax.googleapis.com عمداً اینجا نیست — در Asset Replacer جایگزین محلی دارد
        if (!empty($settings['block_google_services'])) {
            $blocked = array_merge($blocked, [
                'www.google-analytics.com',
                'www.googletagmanager.com',
                'pagead2.googlesyndication.com',
                'maps.googleapis.com',
                'www.gstatic.com',
                'apis.google.com',
                'accounts.google.com',
                'play.google.com',
                'translate.googleapis.com',
            ]);
        }

        // Google Analytics
        if (!empty($settings['block_google_analytics'])) {
            $blocked = array_merge($blocked, [
                'www.google-analytics.com',
                'ssl.google-analytics.com',
                'analytics.google.com',
                'www.googletagmanager.com',
            ]);
        }

        // WordPress.com
        if (!empty($settings['block_wp_services'])) {
            $blocked = array_merge($blocked, [
                'wp-stats.goldgate.us',
                'wp-pixel.goldgate.us',
                's.w.org',
                's0.wp.com', 's1.wp.com', 's2.wp.com',
                'widgets.wp.com',
                'i0.wp.com', 'i1.wp.com', 'i2.wp.com',
                'c0.wp.com',
                'public-api.wordpress.com',
            ]);
        }

        // WP Stats
        if (!empty($settings['block_wp_stats'])) {
            $blocked = array_merge($blocked, [
                'wp-stats.goldgate.us',          // ✅ اضافه شد — woo-tracks
                'wp-pixel.goldgate.us',          // ✅ اضافه شد — tracking pixel
                'wp-stats.goldgate.us',
                'wp-pixel.goldgate.us',
            ]);
        }

        // Jetpack
        if (!empty($settings['block_jetpack'])) {
            $blocked = array_merge($blocked, [
                'jetpack.wordpress.com',
                'connect.wordpress.com',
                'jetpack.com',
            ]);
        }

        // Gravatar
        if (!empty($settings['block_gravatar'])) {
            $blocked = array_merge($blocked, [
                'gravatar.com',
                'secure.gravatar.com',
                '0.gravatar.com', '1.gravatar.com', '2.gravatar.com',
            ]);
        }

        // Elementor External — فقط tracking، نه library
        if (!empty($settings['block_elementor_ext'])) {
            $blocked = array_merge($blocked, [
                'my.elementor.com',
                // ⚠️ library.elementor.com عمداً حذف شده — برای وارد کردن قالب لازم است
            ]);
        }

        return array_unique($blocked);
    }

    /**
     * دامنه‌های ضروری وایت‌لیست (هرگز مسدود نمی‌شوند)
     */
    private function get_essential_whitelist() {
        return [
            'api.wordpress.org',      // آپدیت‌های وردپرس
            'downloads.wordpress.org', // دانلود افزونه/قالب
        ];
    }

    private function register_hooks() {
        // مسدودسازی HTTP — اولویت بالاتر از Asset Replacer
        add_filter('pre_http_request', [$this, 'filter_http_request'], 5, 3);

        // لاگ در shutdown
        $settings = get_option('wpiso_settings', []);
        if (!empty($settings['log_blocked_requests'])) {
            add_action('shutdown', [$this, 'save_request_log']);
        }
    }

    /**
     * فیلتر اصلی — بر اساس حالت blacklist یا whitelist
     */
    public function filter_http_request($preempt, $args, $url) {
        if (!is_string($url) || empty($url)) return $preempt;

        $host = parse_url($url, PHP_URL_HOST);
        if (empty($host)) return $preempt;

        // سایت خودمان همیشه مجاز است
        $site_host = parse_url(home_url(), PHP_URL_HOST);
        if ($host === $site_host) return $preempt;

        // وایت‌لیست — همیشه مجاز
        if ($this->is_whitelisted($host)) {
            return $preempt;
        }

        $should_block = false;

        if ($this->filter_mode === 'whitelist') {
            // حالت وایت‌لیست: همه چیز مسدود مگر اینکه در وایت‌لیست باشد
            $should_block = true;
        } else {
            // حالت بلک‌لیست: فقط دامنه‌های مسدود
            $settings = get_option('wpiso_settings', []);
            if (!empty($settings['block_all_external'])) {
                // همه خارجی‌ها مسدود (مگر وایت‌لیست)
                $should_block = true;
            } else {
                $should_block = $this->is_blocked($host);
            }
        }

        if ($should_block) {
            $this->log_request($host, $url, 'blocked');
            return new WP_Error(
                'wpiso_domain_blocked',
                sprintf('[WPISO] درخواست به %s مسدود شد.', esc_html($host))
            );
        }

        return $preempt;
    }

    /**
     * آیا دامنه در وایت‌لیست است؟
     */
    public function is_whitelisted($host) {
        foreach ($this->whitelisted as $allowed) {
            if ($host === $allowed || $this->domain_matches($host, $allowed)) {
                return true;
            }
        }
        return false;
    }

    /**
     * آیا دامنه مسدود است؟ (ترکیب پیش‌فرض + سفارشی)
     */
    public function is_blocked($host) {
        $all_blocked = array_merge($this->default_blocked, $this->custom_blocked);
        foreach ($all_blocked as $blocked) {
            if ($host === $blocked || $this->domain_matches($host, $blocked)) {
                return true;
            }
        }
        return false;
    }

    /**
     * مطابقت دامنه (شامل ساب‌دامنه‌ها)
     * مثلاً sub.example.com مطابق example.com است
     */
    private function domain_matches($host, $pattern) {
        // الگوی wildcard: *.example.com
        if (strpos($pattern, '*.') === 0) {
            $base = substr($pattern, 2);
            return ($host === $base || substr($host, -strlen('.' . $base)) === '.' . $base);
        }

        // مطابقت ساب‌دامنه
        return (substr($host, -strlen('.' . $pattern)) === '.' . $pattern);
    }

    /**
     * لاگ درخواست
     */
    private function log_request($host, $url, $action) {
        $this->request_log[] = [
            'time'   => current_time('mysql'),
            'host'   => $host,
            'url'    => substr($url, 0, 200),
            'action' => $action,
        ];
    }

    /**
     * ذخیره لاگ در دیتابیس (حداکثر ۱۰۰ مورد آخر)
     */
    public function save_request_log() {
        if (empty($this->request_log)) return;

        $existing = get_option('wpiso_request_log', []);
        $merged = array_merge($existing, $this->request_log);
        $merged = array_slice($merged, -100); // فقط ۱۰۰ تای آخر
        update_option('wpiso_request_log', $merged, false);
    }

    /* ───── متدهای عمومی برای UI ───── */

    public function get_all_blocked_domains() {
        return array_unique(array_merge($this->default_blocked, $this->custom_blocked));
    }

    public function get_custom_blocked() {
        return $this->custom_blocked;
    }

    public function get_whitelisted() {
        return $this->whitelisted;
    }

    public function get_filter_mode() {
        return $this->filter_mode;
    }

    public static function get_request_log() {
        return get_option('wpiso_request_log', []);
    }

    public static function clear_request_log() {
        delete_option('wpiso_request_log');
    }
}
