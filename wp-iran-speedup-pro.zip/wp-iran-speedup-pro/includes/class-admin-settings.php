<?php
/**
 * Admin Settings v4.0.0
 *
 * صفحه تنظیمات پیشرفته — تب‌بندی شده با مدیریت فونت، وایت‌لیست/بلک‌لیست
 *
 * @package WPISO
 * @since   4.0.0
 */

if (!defined('ABSPATH')) exit;

class WPISO_Admin_Settings {
    private static $instance = null;

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        if (!is_admin()) return;

        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_notices', [$this, 'show_notice']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
    }

    public function add_menu() {
        add_menu_page(
            'بهینه‌ساز سرعت ایران',
            '⚡ بهینه‌ساز ایران',
            'manage_options',
            'wpiso-settings',
            [$this, 'render_page'],
            'dashicons-performance',
            80
        );
    }

    public function enqueue_admin_assets($hook) {
        if ($hook !== 'toplevel_page_wpiso-settings') return;

        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_enqueue_media();

        // Inline admin CSS
        wp_add_inline_style('wp-admin', $this->get_admin_css());
    }

    public function render_page() {
        if (!current_user_can('manage_options')) {
            wp_die('دسترسی ندارید.');
        }

        $settings = get_option('wpiso_settings', WPISO_Core::get_default_settings());
        $custom_blocked = get_option('wpiso_custom_blocked_domains', []);
        $whitelisted = get_option('wpiso_whitelisted_domains', []);
        $custom_fonts = get_option('wpiso_custom_fonts', []);
        $request_log = WPISO_Domain_Manager::get_request_log();

        $nonce = wp_create_nonce('wpiso_nonce');
        ?>
        <div class="wrap wpiso-wrap" dir="rtl">
            <div class="wpiso-header">
                <h1>⚡ بهینه‌ساز سرعت ایران <span class="wpiso-version">v<?php echo esc_html(WPISO_VERSION); ?></span></h1>
                <p class="wpiso-desc">مدیریت کامل بهینه‌سازی سرعت، فونت‌ها، و فیلترینگ دامنه‌ها برای شرایط ایران</p>
            </div>

            <!-- تب‌ها -->
            <nav class="wpiso-tabs">
                <a href="#tab-general" class="wpiso-tab active" data-tab="tab-general">🛡️ تنظیمات عمومی</a>
                <a href="#tab-fonts" class="wpiso-tab" data-tab="tab-fonts">🔤 مدیریت فونت</a>
                <a href="#tab-domains" class="wpiso-tab" data-tab="tab-domains">🌐 مدیریت دامنه‌ها</a>
                <a href="#tab-performance" class="wpiso-tab" data-tab="tab-performance">🚀 بهینه‌سازی</a>
                <a href="#tab-status" class="wpiso-tab" data-tab="tab-status">📊 وضعیت و لاگ</a>
                <a href="#tab-tools" class="wpiso-tab" data-tab="tab-tools">🔧 ابزارها</a>
            </nav>

            <form id="wpiso-settings-form">
                <input type="hidden" name="nonce" value="<?php echo esc_attr($nonce); ?>">

                <!-- ═══════ تب تنظیمات عمومی ═══════ -->
                <div id="tab-general" class="wpiso-tab-content active">
                    <div class="wpiso-cards-row">
                        <div class="wpiso-card">
                            <h2>🛡️ مسدودسازی سرویس‌ها</h2>
                            <p class="wpiso-card-desc">سرویس‌های خارجی که در ایران فیلتر هستند و باعث کندی سایت می‌شوند را مسدود کنید.</p>
                            <table class="wpiso-toggle-table">
                                <?php
                                $blocking_options = [
                                    'block_google_fonts'     => ['عنوان' => 'Google Fonts', 'توضیح' => 'فونت‌های گوگل (fonts.googleapis.com)'],
                                    'block_gravatar'         => ['عنوان' => 'Gravatar', 'توضیح' => 'تصاویر آواتار (gravatar.com)'],
                                    'block_wp_stats'         => ['عنوان' => 'WordPress.com Stats', 'توضیح' => 'آمارگیر وردپرس (wp-stats.goldgate.us)'],
                                    'block_google_analytics' => ['عنوان' => 'Google Analytics', 'توضیح' => 'گوگل آنالیتیکس و تگ منیجر'],
                                    'block_google_services'  => ['عنوان' => 'Google APIs', 'توضیح' => 'سایر سرویس‌های گوگل (Maps, APIs, ...)'],
                                    'block_wp_services'      => ['عنوان' => 'WordPress.com CDN', 'توضیح' => 'شبکه CDN وردپرس (wp.com)'],
                                    'block_jetpack'          => ['عنوان' => 'Jetpack', 'توضیح' => 'سرویس‌های جت‌پک'],
                                    'block_elementor_ext'    => ['عنوان' => 'Elementor External', 'توضیح' => 'درخواست‌های خارجی المنتور'],
                                ];
                                foreach ($blocking_options as $key => $opt): ?>
                                <tr>
                                    <td class="wpiso-toggle-cell">
                                        <label class="wpiso-switch">
                                            <input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(!empty($settings[$key])); ?>>
                                            <span class="wpiso-slider"></span>
                                        </label>
                                    </td>
                                    <td>
                                        <strong><?php echo esc_html($opt['عنوان']); ?></strong>
                                        <span class="wpiso-option-desc"><?php echo esc_html($opt['توضیح']); ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>

                        <div class="wpiso-card">
                            <h2>🔄 جایگزینی‌های محلی</h2>
                            <p class="wpiso-card-desc">منابع خارجی را با نسخه‌های محلی سرو شده از سرور خودتان جایگزین کنید.</p>
                            <table class="wpiso-toggle-table">
                                <?php
                                $replace_options = [
                                    'replace_jquery'      => ['عنوان' => 'jQuery', 'توضیح' => 'جایگزینی jQuery از CDN گوگل با نسخه محلی'],
                                    'replace_fontawesome' => ['عنوان' => 'Font Awesome', 'توضیح' => 'سرو محلی آیکون‌های Font Awesome'],
                                ];
                                foreach ($replace_options as $key => $opt): ?>
                                <tr>
                                    <td class="wpiso-toggle-cell">
                                        <label class="wpiso-switch">
                                            <input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(!empty($settings[$key])); ?>>
                                            <span class="wpiso-slider"></span>
                                        </label>
                                    </td>
                                    <td>
                                        <strong><?php echo esc_html($opt['عنوان']); ?></strong>
                                        <span class="wpiso-option-desc"><?php echo esc_html($opt['توضیح']); ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- ═══════ تب مدیریت فونت ═══════ -->
                <div id="tab-fonts" class="wpiso-tab-content">
                    <div class="wpiso-cards-row">
                        <div class="wpiso-card wpiso-card-wide">
                            <h2>🔤 انتخاب و مدیریت فونت دلخواه</h2>
                            <p class="wpiso-card-desc">فونت دلخواه فارسی/عربی خود را انتخاب کنید یا فونت سفارشی آپلود نمایید. فونت به صورت محلی سرو می‌شود و نیازی به سرور خارجی ندارد.</p>

                            <table class="form-table wpiso-form-table">
                                <tr>
                                    <th>فعال‌سازی فونت سفارشی</th>
                                    <td>
                                        <label class="wpiso-switch">
                                            <input type="checkbox" name="custom_font_enabled" value="1" <?php checked(!empty($settings['custom_font_enabled'])); ?> id="wpiso-font-toggle">
                                            <span class="wpiso-slider"></span>
                                        </label>
                                    </td>
                                </tr>
                                <tr class="wpiso-font-options">
                                    <th>انتخاب فونت</th>
                                    <td>
                                        <select name="custom_font_name" id="wpiso-font-select" class="wpiso-select">
                                            <option value="">— انتخاب کنید —</option>
                                            <optgroup label="📦 فونت‌های پیش‌فرض فارسی (CDN + دانلود محلی)">
                                                <?php
                                                $font_mgr = WPISO_Font_Manager::init();
                                                $builtin = $font_mgr->get_builtin_fonts();
                                                foreach ($builtin as $key => $font):
                                                    $status = $font_mgr->get_builtin_font_status($key);
                                                    $local_count = count(array_filter($status, function($s){ return $s['local_exists']; }));
                                                    $total_count = count($status);
                                                    $badge = $local_count > 0 ? "📁{$local_count}/{$total_count}" : '☁️CDN';
                                                ?>
                                                <option value="<?php echo esc_attr($font['name']); ?>"
                                                    data-font-key="<?php echo esc_attr($key); ?>"
                                                    <?php selected($settings['custom_font_name'] ?? '', $font['name']); ?>>
                                                    <?php echo esc_html($font['label'] . ' (' . $font['name'] . ') ' . $badge); ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            <?php
                                            $uploaded = WPISO_Font_Manager::get_uploaded_fonts();
                                            if (!empty($uploaded)): ?>
                                            <optgroup label="📤 فونت‌های آپلود شده">
                                                <?php foreach ($uploaded as $name => $group): ?>
                                                <option value="<?php echo esc_attr($name); ?>"
                                                    <?php selected($settings['custom_font_name'] ?? '', $name); ?>>
                                                    <?php echo esc_html($name); ?> (<?php echo count($group['files']); ?> فایل)
                                                </option>
                                                <?php endforeach; ?>
                                            </optgroup>
                                            <?php endif; ?>
                                        </select>
                                        <p class="description">
                                            ☁️CDN = مستقیم از سرور CDN لود می‌شود &nbsp;|&nbsp;
                                            📁 = فایل روی سرور شما دانلود شده
                                        </p>
                                        <button type="button" id="wpiso-download-font-btn" class="button" style="margin-top:8px;">
                                            📥 دانلود فونت انتخاب‌شده به سرور محلی
                                        </button>
                                        <span id="wpiso-download-status" class="wpiso-status-msg"></span>
                                    </td>
                                </tr>
                                <tr class="wpiso-font-options">
                                    <th>اعمال فونت روی</th>
                                    <td>
                                        <select name="custom_font_target" class="wpiso-select">
                                            <option value="body" <?php selected($settings['custom_font_target'] ?? '', 'body'); ?>>کل سایت (body)</option>
                                            <option value="headings" <?php selected($settings['custom_font_target'] ?? '', 'headings'); ?>>فقط تیترها (h1-h6)</option>
                                            <option value="both" <?php selected($settings['custom_font_target'] ?? '', 'both'); ?>>هر دو (body + تیترها)</option>
                                            <option value="custom" <?php selected($settings['custom_font_target'] ?? '', 'custom'); ?>>سلکتور سفارشی CSS</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr class="wpiso-font-options">
                                    <th>وزن فونت</th>
                                    <td>
                                        <select name="custom_font_weight" class="wpiso-select">
                                            <?php
                                            $weights = ['100'=>'Thin','200'=>'Extra Light','300'=>'Light','400'=>'Regular','500'=>'Medium','600'=>'Semi Bold','700'=>'Bold','800'=>'Extra Bold','900'=>'Black'];
                                            foreach ($weights as $val => $label): ?>
                                            <option value="<?php echo esc_attr($val); ?>" <?php selected($settings['custom_font_weight'] ?? '400', $val); ?>>
                                                <?php echo esc_html("$val — $label"); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                </tr>
                                <tr class="wpiso-font-options">
                                    <th>Font Display</th>
                                    <td>
                                        <select name="font_display" class="wpiso-select">
                                            <option value="swap" <?php selected($settings['font_display'] ?? 'swap', 'swap'); ?>>swap (توصیه شده)</option>
                                            <option value="auto" <?php selected($settings['font_display'] ?? '', 'auto'); ?>>auto</option>
                                            <option value="block" <?php selected($settings['font_display'] ?? '', 'block'); ?>>block</option>
                                            <option value="fallback" <?php selected($settings['font_display'] ?? '', 'fallback'); ?>>fallback</option>
                                            <option value="optional" <?php selected($settings['font_display'] ?? '', 'optional'); ?>>optional</option>
                                        </select>
                                        <p class="description">swap باعث می‌شود تا زمان لود فونت، فونت پیش‌فرض نمایش داده شود.</p>
                                    </td>
                                </tr>
                                <tr class="wpiso-font-options">
                                    <th>پیش‌نمایش</th>
                                    <td>
                                        <div id="wpiso-font-preview" class="wpiso-font-preview">
                                            <p class="preview-fa">بهینه‌ساز سرعت وردپرس برای ایران</p>
                                            <p class="preview-en">WordPress Speed Optimizer for Iran — 0123456789</p>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- آپلود فونت سفارشی -->
                    <div class="wpiso-cards-row">
                        <div class="wpiso-card">
                            <h2>📤 آپلود فونت سفارشی</h2>
                            <p class="wpiso-card-desc">فایل فونت خود را آپلود کنید (فرمت‌های مجاز: woff2, woff, ttf, otf, eot)</p>
                            <div class="wpiso-upload-form">
                                <div class="wpiso-field">
                                    <label>نام فونت:</label>
                                    <input type="text" id="wpiso-upload-font-name" placeholder="مثال: IRANYekan" class="wpiso-input">
                                </div>
                                <div class="wpiso-field-row">
                                    <div class="wpiso-field">
                                        <label>وزن:</label>
                                        <select id="wpiso-upload-font-weight" class="wpiso-select">
                                            <?php foreach ($weights as $val => $label): ?>
                                            <option value="<?php echo esc_attr($val); ?>" <?php selected($val, '400'); ?>><?php echo esc_html("$val — $label"); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="wpiso-field">
                                        <label>استایل:</label>
                                        <select id="wpiso-upload-font-style" class="wpiso-select">
                                            <option value="normal">Normal</option>
                                            <option value="italic">Italic</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="wpiso-field">
                                    <label>فایل فونت:</label>
                                    <input type="file" id="wpiso-upload-font-file" accept=".woff,.woff2,.ttf,.otf,.eot">
                                </div>
                                <button type="button" id="wpiso-upload-font-btn" class="button button-primary">📤 آپلود فونت</button>
                                <div id="wpiso-upload-status" class="wpiso-status-msg"></div>
                            </div>
                        </div>

                        <div class="wpiso-card">
                            <h2>📋 فونت‌های آپلود شده</h2>
                            <div id="wpiso-uploaded-fonts-list">
                                <?php if (empty($custom_fonts)): ?>
                                    <p class="wpiso-empty">هنوز فونتی آپلود نشده است.</p>
                                <?php else: ?>
                                    <table class="widefat striped">
                                        <thead>
                                            <tr><th>نام</th><th>وزن</th><th>فرمت</th><th>عملیات</th></tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($custom_fonts as $id => $font): ?>
                                            <tr id="font-row-<?php echo esc_attr($id); ?>">
                                                <td><?php echo esc_html($font['name']); ?></td>
                                                <td><?php echo esc_html($font['weight'] . ' ' . $font['style']); ?></td>
                                                <td><code><?php echo esc_html($font['format']); ?></code></td>
                                                <td>
                                                    <button type="button" class="button button-small wpiso-delete-font" data-font-id="<?php echo esc_attr($id); ?>">🗑️ حذف</button>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ═══════ تب مدیریت دامنه‌ها ═══════ -->
                <div id="tab-domains" class="wpiso-tab-content">
                    <div class="wpiso-cards-row">
                        <div class="wpiso-card wpiso-card-wide">
                            <h2>🌐 حالت فیلترینگ دامنه‌ها</h2>
                            <p class="wpiso-card-desc">حالت فیلترینگ را انتخاب کنید. در حالت بلک‌لیست فقط دامنه‌های مشخص‌شده مسدود می‌شوند. در حالت وایت‌لیست همه دامنه‌ها مسدود هستند مگر موارد مجاز.</p>

                            <div class="wpiso-filter-mode">
                                <label class="wpiso-radio-card <?php echo ($settings['domain_filter_mode'] ?? 'blacklist') === 'blacklist' ? 'active' : ''; ?>">
                                    <input type="radio" name="domain_filter_mode" value="blacklist" <?php checked($settings['domain_filter_mode'] ?? 'blacklist', 'blacklist'); ?>>
                                    <div class="wpiso-radio-content">
                                        <strong>🚫 بلک‌لیست (پیشنهادی)</strong>
                                        <p>فقط دامنه‌های مشخص‌شده مسدود می‌شوند. سایر دامنه‌ها آزاد هستند.</p>
                                    </div>
                                </label>
                                <label class="wpiso-radio-card <?php echo ($settings['domain_filter_mode'] ?? '') === 'whitelist' ? 'active' : ''; ?>">
                                    <input type="radio" name="domain_filter_mode" value="whitelist" <?php checked($settings['domain_filter_mode'] ?? '', 'whitelist'); ?>>
                                    <div class="wpiso-radio-content">
                                        <strong>✅ وایت‌لیست (حداکثر امنیت)</strong>
                                        <p>همه دامنه‌های خارجی مسدود هستند مگر اینکه در لیست مجاز باشند.</p>
                                    </div>
                                </label>
                            </div>

                            <div class="wpiso-toggle-row" style="margin-top:15px;">
                                <label class="wpiso-switch">
                                    <input type="checkbox" name="block_all_external" value="1" <?php checked(!empty($settings['block_all_external'])); ?>>
                                    <span class="wpiso-slider"></span>
                                </label>
                                <span><strong>مسدودسازی کامل تمام درخواست‌های خارجی</strong> — همه درخواست‌ها به سرورهای خارج مسدود می‌شوند (مگر وایت‌لیست). ⚠️ ممکن است برخی قابلیت‌ها از کار بیفتد.</span>
                            </div>
                        </div>
                    </div>

                    <div class="wpiso-cards-row">
                        <div class="wpiso-card">
                            <h2>🚫 دامنه‌های مسدود (بلک‌لیست سفارشی)</h2>
                            <p class="wpiso-card-desc">دامنه‌هایی که می‌خواهید علاوه بر لیست پیش‌فرض مسدود شوند. هر دامنه در یک خط.</p>
                            <textarea name="custom_blocked_domains" class="wpiso-textarea" rows="10" placeholder="example.com&#10;cdn.example.com&#10;tracker.analytics.com"><?php echo esc_textarea(implode("\n", $custom_blocked)); ?></textarea>
                            <div class="wpiso-domain-tools">
                                <input type="text" id="wpiso-test-domain" placeholder="دامنه‌ای برای تست..." class="wpiso-input wpiso-input-inline">
                                <button type="button" id="wpiso-test-domain-btn" class="button">🔍 تست دسترسی</button>
                                <span id="wpiso-test-result" class="wpiso-status-msg"></span>
                            </div>
                        </div>

                        <div class="wpiso-card">
                            <h2>✅ دامنه‌های مجاز (وایت‌لیست)</h2>
                            <p class="wpiso-card-desc">دامنه‌هایی که هرگز مسدود نمی‌شوند (حتی در حالت وایت‌لیست). دامنه‌های ضروری وردپرس به‌صورت خودکار مجاز هستند.</p>
                            <textarea name="whitelisted_domains" class="wpiso-textarea" rows="10" placeholder="api.wordpress.org&#10;my-cdn.example.com&#10;payment-gateway.ir"><?php echo esc_textarea(implode("\n", $whitelisted)); ?></textarea>
                            <div class="wpiso-whitelist-presets">
                                <p><strong>پیش‌فرض‌های رایج:</strong></p>
                                <button type="button" class="button wpiso-preset-btn" data-domains="api.wordpress.org&#10;downloads.wordpress.org">🔧 آپدیت وردپرس</button>
                                <button type="button" class="button wpiso-preset-btn" data-domains="checkout.zarinpal.com&#10;api.zarinpal.com&#10;zarinpal.com">💳 زرین‌پال</button>
                                <button type="button" class="button wpiso-preset-btn" data-domains="api.idpay.ir&#10;idpay.ir">💳 آیدی‌پی</button>
                                <button type="button" class="button wpiso-preset-btn" data-domains="sep.shaparak.ir&#10;mabna.shaparak.ir&#10;pec.shaparak.ir&#10;ikc.shaparak.ir&#10;sadad.shaparak.ir">💳 درگاه شاپرک</button>
                                <button type="button" class="button wpiso-preset-btn" data-domains="api.sms.ir&#10;rest.payamak-panel.com&#10;api.kavenegar.com">📱 سرویس پیامک</button>
                            </div>
                        </div>
                    </div>

                    <!-- لاگ‌ها -->
                    <div class="wpiso-cards-row">
                        <div class="wpiso-card wpiso-card-wide">
                            <h2>📋 لاگ فیلترینگ</h2>
                            <div class="wpiso-toggle-row">
                                <label class="wpiso-switch">
                                    <input type="checkbox" name="log_blocked_requests" value="1" <?php checked(!empty($settings['log_blocked_requests'])); ?>>
                                    <span class="wpiso-slider"></span>
                                </label>
                                <span>فعال‌سازی لاگ درخواست‌های مسدود شده</span>
                            </div>
                            <?php if (!empty($request_log)): ?>
                            <table class="widefat striped" style="margin-top:10px;">
                                <thead>
                                    <tr><th>زمان</th><th>دامنه</th><th>URL</th><th>وضعیت</th></tr>
                                </thead>
                                <tbody>
                                <?php foreach (array_reverse(array_slice($request_log, -20)) as $log): ?>
                                    <tr>
                                        <td><small><?php echo esc_html($log['time']); ?></small></td>
                                        <td><code><?php echo esc_html($log['host']); ?></code></td>
                                        <td><small title="<?php echo esc_attr($log['url']); ?>"><?php echo esc_html(mb_substr($log['url'], 0, 60)); ?>…</small></td>
                                        <td><span class="wpiso-badge wpiso-badge-red">مسدود</span></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <button type="button" id="wpiso-clear-log" class="button" style="margin-top:8px;">🗑️ پاک کردن لاگ</button>
                            <?php else: ?>
                            <p class="wpiso-empty" style="margin-top:10px;">هنوز لاگی ثبت نشده.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- ═══════ تب بهینه‌سازی ═══════ -->
                <div id="tab-performance" class="wpiso-tab-content">
                    <div class="wpiso-cards-row">
                        <div class="wpiso-card">
                            <h2>🚀 بهینه‌سازی عملکرد</h2>
                            <table class="wpiso-toggle-table">
                                <?php
                                $perf_options = [
                                    'disable_emoji'     => ['عنوان' => 'حذف Emoji Scripts', 'توضیح' => 'حذف اسکریپت‌های ایموجی وردپرس از head'],
                                    'disable_embeds'    => ['عنوان' => 'غیرفعال‌سازی oEmbed', 'توضیح' => 'حذف oEmbed و embed‌های خارجی'],
                                    'disable_heartbeat' => ['عنوان' => 'محدودسازی Heartbeat', 'توضیح' => 'غیرفعال در فرانت‌اند، فعال فقط در ویرایشگر'],
                                    'disable_xmlrpc'    => ['عنوان' => 'غیرفعال XML-RPC', 'توضیح' => 'مسدودسازی XML-RPC (امنیت + عملکرد)'],
                                    'disable_rss'       => ['عنوان' => 'حذف فیدهای RSS اضافی', 'توضیح' => 'حذف لینک فیدهای اضافی از head'],
                                    'limit_revisions'   => ['عنوان' => 'محدودسازی Revisions', 'توضیح' => 'حداکثر ۳ نسخه پشتیبان برای هر پست'],
                                    'optimize_updates'  => ['عنوان' => 'بهینه‌سازی آپدیت‌ها', 'توضیح' => 'غیرفعال کردن بررسی خودکار آپدیت (جلوگیری از timeout)'],
                                ];
                                foreach ($perf_options as $key => $opt): ?>
                                <tr>
                                    <td class="wpiso-toggle-cell">
                                        <label class="wpiso-switch">
                                            <input type="checkbox" name="<?php echo esc_attr($key); ?>" value="1" <?php checked(!empty($settings[$key])); ?>>
                                            <span class="wpiso-slider"></span>
                                        </label>
                                    </td>
                                    <td>
                                        <strong><?php echo esc_html($opt['عنوان']); ?></strong>
                                        <span class="wpiso-option-desc"><?php echo esc_html($opt['توضیح']); ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>

                        <div class="wpiso-card">
                            <h2>ℹ️ موارد حذف شده از Head</h2>
                            <ul class="wpiso-list">
                                <li>✅ RSD Link</li>
                                <li>✅ WLW Manifest Link</li>
                                <li>✅ WordPress Generator Meta Tag</li>
                                <li>✅ Shortlink</li>
                                <li>✅ REST API Link</li>
                                <li>✅ DNS Prefetch / Preconnect خارجی</li>
                                <li>✅ Feed Links Extra</li>
                                <li>✅ Stats/Tracking Scripts</li>
                                <li>✅ Jetpack DNS Prefetch</li>
                                <li>✅ Inline Google Fonts</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- ═══════ تب وضعیت ═══════ -->
                <div id="tab-status" class="wpiso-tab-content">
                    <?php $this->render_status_tab(); ?>
                </div>

                <!-- ═══════ تب ابزارها ═══════ -->
                <div id="tab-tools" class="wpiso-tab-content">
                    <div class="wpiso-cards-row">
                        <div class="wpiso-card">
                            <h2>📥 پشتیبان‌گیری تنظیمات</h2>
                            <p class="wpiso-card-desc">تنظیمات فعلی افزونه را خروجی بگیرید یا از فایل پشتیبان بازیابی کنید.</p>
                            <button type="button" id="wpiso-export-btn" class="button button-primary">📥 خروجی تنظیمات (JSON)</button>
                            <hr>
                            <p><strong>بازیابی تنظیمات:</strong></p>
                            <textarea id="wpiso-import-data" class="wpiso-textarea" rows="5" placeholder='فایل JSON خروجی‌شده را اینجا بچسبانید...'></textarea>
                            <button type="button" id="wpiso-import-btn" class="button">📤 بازیابی تنظیمات</button>
                        </div>
                        <div class="wpiso-card">
                            <h2>🔄 بازنشانی</h2>
                            <p class="wpiso-card-desc">بازگشت به تنظیمات پیش‌فرض افزونه</p>
                            <button type="button" id="wpiso-reset-btn" class="button button-secondary">🔄 بازنشانی تنظیمات</button>
                            <hr>
                            <h3>🧹 پاکسازی</h3>
                            <button type="button" id="wpiso-clear-cache-btn" class="button">🗑️ پاک کردن کش transient</button>
                            <button type="button" id="wpiso-clear-log-btn2" class="button">🗑️ پاک کردن لاگ</button>
                        </div>
                    </div>
                </div>

                <!-- دکمه ذخیره (ثابت پایین) -->
                <div class="wpiso-save-bar">
                    <button type="submit" class="button button-primary button-hero" id="wpiso-save-btn">💾 ذخیره تنظیمات</button>
                    <span id="wpiso-save-status" class="wpiso-status-msg"></span>
                </div>
            </form>
        </div>

        <?php $this->render_admin_js($nonce); ?>
        <?php
    }

    /**
     * تب وضعیت
     */
    private function render_status_tab() {
        $assets_status = [
            'jQuery (3.6.0)'       => file_exists(WPISO_PATH . 'assets/js/jquery.min.js'),
            'jQuery UI JS'         => file_exists(WPISO_PATH . 'assets/js/jquery-ui.min.js'),
            'jQuery UI CSS'        => file_exists(WPISO_PATH . 'assets/css/jquery-ui.min.css'),
            'Bootstrap CSS'        => file_exists(WPISO_PATH . 'assets/css/bootstrap.min.css'),
            'Bootstrap JS'         => file_exists(WPISO_PATH . 'assets/js/bootstrap.min.js'),
            'Font Awesome CSS'     => file_exists(WPISO_PATH . 'assets/css/all.min.css'),
            'FA Solid (woff2)'     => file_exists(WPISO_PATH . 'assets/webfonts/fa-solid-900.woff2'),
            'FA Brands (woff2)'    => file_exists(WPISO_PATH . 'assets/webfonts/fa-brands-400.woff2'),
            'FA Regular (woff2)'   => file_exists(WPISO_PATH . 'assets/webfonts/fa-regular-400.woff2'),
            'Default Avatar'       => file_exists(WPISO_PATH . 'assets/img/default-avatar.svg'),
        ];
        ?>
        <div class="wpiso-cards-row">
            <div class="wpiso-card">
                <h2>📦 فایل‌های محلی</h2>
                <table class="widefat striped">
                    <tbody>
                    <?php foreach ($assets_status as $name => $exists): ?>
                        <tr>
                            <td style="width:30px;"><?php echo $exists ? '✅' : '❌'; ?></td>
                            <td><?php echo esc_html($name); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php
                $missing = array_filter($assets_status, function($v) { return !$v; });
                if (!empty($missing)): ?>
                <div class="notice notice-warning inline" style="margin-top:10px;">
                    <p><strong>هشدار:</strong> فایل‌های بالا با علامت ❌ وجود ندارند.</p>
                </div>
                <?php endif; ?>
            </div>

            <div class="wpiso-card">
                <h2>ℹ️ اطلاعات سیستم</h2>
                <table class="form-table">
                    <tr><th>نسخه افزونه:</th><td><code><?php echo esc_html(WPISO_VERSION); ?></code></td></tr>
                    <tr><th>نسخه وردپرس:</th><td><code><?php echo esc_html(get_bloginfo('version')); ?></code></td></tr>
                    <tr><th>نسخه PHP:</th><td><code><?php echo esc_html(PHP_VERSION); ?></code></td></tr>
                    <tr><th>مسیر افزونه:</th><td><code style="font-size:11px;"><?php echo esc_html(WPISO_PATH); ?></code></td></tr>
                    <tr>
                        <th>Elementor:</th>
                        <td><?php echo defined('ELEMENTOR_VERSION') ? '✅ v' . esc_html(ELEMENTOR_VERSION) : '—'; ?></td>
                    </tr>
                    <tr>
                        <th>WooCommerce:</th>
                        <td><?php echo defined('WC_VERSION') ? '✅ v' . esc_html(WC_VERSION) : '—'; ?></td>
                    </tr>
                    <tr>
                        <th>فونت‌های آپلود شده:</th>
                        <td><?php echo count(get_option('wpiso_custom_fonts', [])); ?> فایل</td>
                    </tr>
                    <tr>
                        <th>دامنه‌های بلک‌لیست:</th>
                        <td><?php echo count(get_option('wpiso_custom_blocked_domains', [])); ?> مورد سفارشی</td>
                    </tr>
                    <tr>
                        <th>دامنه‌های وایت‌لیست:</th>
                        <td><?php echo count(get_option('wpiso_whitelisted_domains', [])); ?> مورد</td>
                    </tr>
                </table>
            </div>
        </div>
        <?php
    }

    /**
     * اسکریپت‌های ادمین
     */
    private function render_admin_js($nonce) {
        ?>
        <script>
        (function() {
            'use strict';
            var ajaxurl = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
            var nonce = '<?php echo esc_js($nonce); ?>';

            /* ═══ تب‌ها ═══ */
            document.querySelectorAll('.wpiso-tab').forEach(function(tab) {
                tab.addEventListener('click', function(e) {
                    e.preventDefault();
                    document.querySelectorAll('.wpiso-tab').forEach(function(t){ t.classList.remove('active'); });
                    document.querySelectorAll('.wpiso-tab-content').forEach(function(c){ c.classList.remove('active'); });
                    this.classList.add('active');
                    document.getElementById(this.dataset.tab).classList.add('active');
                    window.location.hash = this.dataset.tab;
                });
            });
            // باز کردن تب از hash
            if(window.location.hash) {
                var h = window.location.hash.substring(1);
                var t = document.querySelector('[data-tab="'+h+'"]');
                if(t) t.click();
            }

            /* ═══ ذخیره تنظیمات ═══ */
            document.getElementById('wpiso-settings-form').addEventListener('submit', function(e) {
                e.preventDefault();
                var fd = new FormData(this);
                fd.append('action', 'wpiso_save_settings');
                fetch(ajaxurl, {method:'POST', body:fd})
                .then(function(r){return r.json();})
                .then(function(data) {
                    var st = document.getElementById('wpiso-save-status');
                    st.textContent = data.success ? '✅ ذخیره شد' : '❌ خطا: ' + data.data;
                    st.className = 'wpiso-status-msg ' + (data.success ? 'success' : 'error');
                    setTimeout(function(){ st.textContent = ''; }, 3000);
                });
            });

            /* ═══ تست دامنه ═══ */
            var testBtn = document.getElementById('wpiso-test-domain-btn');
            if(testBtn) {
                testBtn.addEventListener('click', function() {
                    var domain = document.getElementById('wpiso-test-domain').value.trim();
                    if(!domain) return;
                    var result = document.getElementById('wpiso-test-result');
                    result.textContent = '⏳ در حال تست...';
                    var fd = new FormData();
                    fd.append('action','wpiso_test_domain');
                    fd.append('nonce', nonce);
                    fd.append('domain', domain);
                    fetch(ajaxurl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(data) {
                        if(data.success) {
                            var d = data.data;
                            if(d.reachable) {
                                result.textContent = '✅ قابل دسترسی (' + d.time + 'ms — کد: ' + d.code + ')';
                                result.className = 'wpiso-status-msg success';
                            } else {
                                result.textContent = '❌ غیرقابل دسترسی (' + d.time + 'ms) — ' + d.error;
                                result.className = 'wpiso-status-msg error';
                            }
                        }
                    });
                });
            }

            /* ═══ دانلود فونت پیش‌فرض به سرور محلی ═══ */
            var dlBtn = document.getElementById('wpiso-download-font-btn');
            if(dlBtn) {
                dlBtn.addEventListener('click', function() {
                    var sel = document.getElementById('wpiso-font-select');
                    var opt = sel.options[sel.selectedIndex];
                    var fontKey = opt ? opt.dataset.fontKey : '';
                    if(!fontKey) { alert('لطفاً یک فونت پیش‌فرض انتخاب کنید.'); return; }
                    var weightSel = document.querySelector('select[name="custom_font_weight"]');
                    var weight = weightSel ? weightSel.value : '400';
                    var st = document.getElementById('wpiso-download-status');
                    st.textContent = '⏳ در حال دانلود...';
                    st.className = 'wpiso-status-msg';
                    var fd = new FormData();
                    fd.append('action','wpiso_download_builtin_font');
                    fd.append('nonce', nonce);
                    fd.append('font_key', fontKey);
                    fd.append('weight', weight);
                    fetch(ajaxurl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(data) {
                        if(data.success) {
                            st.textContent = '✅ ' + data.data.message + ' (' + data.data.size + ')';
                            st.className = 'wpiso-status-msg success';
                        } else {
                            st.textContent = '❌ ' + data.data;
                            st.className = 'wpiso-status-msg error';
                        }
                    })
                    .catch(function(err) {
                        st.textContent = '❌ خطای شبکه: ' + err.message;
                        st.className = 'wpiso-status-msg error';
                    });
                });
            }

            /* ═══ آپلود فونت ═══ */
            var uploadBtn = document.getElementById('wpiso-upload-font-btn');
            if(uploadBtn) {
                uploadBtn.addEventListener('click', function() {
                    var name = document.getElementById('wpiso-upload-font-name').value.trim();
                    var file = document.getElementById('wpiso-upload-font-file').files[0];
                    if(!name || !file) { alert('نام فونت و فایل را وارد کنید.'); return; }
                    var fd = new FormData();
                    fd.append('action','wpiso_upload_font');
                    fd.append('nonce', nonce);
                    fd.append('font_name', name);
                    fd.append('font_weight', document.getElementById('wpiso-upload-font-weight').value);
                    fd.append('font_style', document.getElementById('wpiso-upload-font-style').value);
                    fd.append('font_file', file);
                    var st = document.getElementById('wpiso-upload-status');
                    st.textContent = '⏳ در حال آپلود...';
                    fetch(ajaxurl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(data) {
                        st.textContent = data.success ? '✅ ' + data.data.message : '❌ ' + data.data;
                        st.className = 'wpiso-status-msg ' + (data.success ? 'success' : 'error');
                        if(data.success) setTimeout(function(){ location.reload(); }, 1500);
                    });
                });
            }

            /* ═══ حذف فونت ═══ */
            document.querySelectorAll('.wpiso-delete-font').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    if(!confirm('آیا از حذف این فونت مطمئن هستید؟')) return;
                    var fid = this.dataset.fontId;
                    var fd = new FormData();
                    fd.append('action','wpiso_delete_font');
                    fd.append('nonce', nonce);
                    fd.append('font_id', fid);
                    fetch(ajaxurl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(data) {
                        if(data.success) {
                            var row = document.getElementById('font-row-' + fid);
                            if(row) row.remove();
                        } else {
                            alert(data.data);
                        }
                    });
                });
            });

            /* ═══ پریست وایت‌لیست ═══ */
            document.querySelectorAll('.wpiso-preset-btn').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var ta = document.querySelector('textarea[name="whitelisted_domains"]');
                    var current = ta.value.trim();
                    var newDomains = this.dataset.domains;
                    ta.value = current ? current + '\n' + newDomains : newDomains;
                });
            });

            /* ═══ خروجی / بازیابی تنظیمات ═══ */
            var expBtn = document.getElementById('wpiso-export-btn');
            if(expBtn) {
                expBtn.addEventListener('click', function() {
                    var fd = new FormData();
                    fd.append('action','wpiso_export_settings');
                    fd.append('nonce', nonce);
                    fetch(ajaxurl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(data) {
                        if(data.success) {
                            var json = JSON.stringify(data.data, null, 2);
                            var blob = new Blob([json], {type:'application/json'});
                            var a = document.createElement('a');
                            a.href = URL.createObjectURL(blob);
                            a.download = 'wpiso-settings-backup.json';
                            a.click();
                        }
                    });
                });
            }

            var impBtn = document.getElementById('wpiso-import-btn');
            if(impBtn) {
                impBtn.addEventListener('click', function() {
                    var json = document.getElementById('wpiso-import-data').value.trim();
                    if(!json) { alert('داده‌ای وارد نشده.'); return; }
                    if(!confirm('آیا مطمئن هستید؟ تنظیمات فعلی جایگزین خواهد شد.')) return;
                    var fd = new FormData();
                    fd.append('action','wpiso_import_settings');
                    fd.append('nonce', nonce);
                    fd.append('import_data', json);
                    fetch(ajaxurl, {method:'POST', body:fd})
                    .then(function(r){return r.json();})
                    .then(function(data) {
                        alert(data.success ? data.data : data.data);
                        if(data.success) location.reload();
                    });
                });
            }

            /* ═══ رادیو کارت‌ها ═══ */
            document.querySelectorAll('.wpiso-radio-card input[type="radio"]').forEach(function(r) {
                r.addEventListener('change', function() {
                    document.querySelectorAll('.wpiso-radio-card').forEach(function(c){ c.classList.remove('active'); });
                    this.closest('.wpiso-radio-card').classList.add('active');
                });
            });

            /* ═══ نمایش/مخفی فونت آپشن‌ها ═══ */
            var fontToggle = document.getElementById('wpiso-font-toggle');
            if(fontToggle) {
                function toggleFontOpts() {
                    var show = fontToggle.checked;
                    document.querySelectorAll('.wpiso-font-options').forEach(function(tr) {
                        tr.style.display = show ? '' : 'none';
                    });
                }
                fontToggle.addEventListener('change', toggleFontOpts);
                toggleFontOpts();
            }
        })();
        </script>
        <?php
    }

    /**
     * CSS ادمین
     */
    private function get_admin_css() {
        return '
        .wpiso-wrap { max-width: 1200px; }
        .wpiso-header { background: linear-gradient(135deg, #1d2327 0%, #2c3338 100%); color: #fff; padding: 25px 30px; border-radius: 12px; margin-bottom: 20px; }
        .wpiso-header h1 { color: #fff; margin: 0 0 5px; font-size: 24px; }
        .wpiso-version { background: rgba(255,255,255,0.15); padding: 2px 10px; border-radius: 12px; font-size: 13px; }
        .wpiso-desc { color: #ccc; margin: 0; font-size: 14px; }

        /* تب‌ها */
        .wpiso-tabs { display: flex; gap: 0; border-bottom: 2px solid #c3c4c7; margin-bottom: 0; flex-wrap: wrap; }
        .wpiso-tab { display: inline-block; padding: 12px 20px; text-decoration: none; color: #50575e; font-weight: 600; border: 1px solid transparent; border-bottom: none; border-radius: 8px 8px 0 0; margin-bottom: -2px; transition: all .2s; font-size: 13px; }
        .wpiso-tab:hover { background: #f0f0f1; color: #1d2327; }
        .wpiso-tab.active { background: #fff; color: #1d2327; border-color: #c3c4c7; border-bottom-color: #fff; }
        .wpiso-tab-content { display: none; padding: 20px 0; }
        .wpiso-tab-content.active { display: block; }

        /* کارت‌ها */
        .wpiso-cards-row { display: flex; gap: 20px; flex-wrap: wrap; margin-bottom: 20px; }
        .wpiso-card { flex: 1; min-width: 320px; background: #fff; border: 1px solid #c3c4c7; border-radius: 8px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.04); }
        .wpiso-card-wide { min-width: 100%; flex-basis: 100%; }
        .wpiso-card h2 { margin: 0 0 5px; font-size: 16px; }
        .wpiso-card-desc { color: #646970; font-size: 13px; margin: 0 0 15px; line-height: 1.6; }

        /* سوییچ */
        .wpiso-switch { position: relative; display: inline-block; width: 44px; height: 24px; flex-shrink: 0; }
        .wpiso-switch input { opacity: 0; width: 0; height: 0; }
        .wpiso-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background: #c3c4c7; border-radius: 24px; transition: .3s; }
        .wpiso-slider:before { content: ""; position: absolute; height: 18px; width: 18px; left: 3px; bottom: 3px; background: #fff; border-radius: 50%; transition: .3s; }
        .wpiso-switch input:checked + .wpiso-slider { background: #2271b1; }
        .wpiso-switch input:checked + .wpiso-slider:before { transform: translateX(20px); }

        /* جدول تنظیمات */
        .wpiso-toggle-table { width: 100%; border-collapse: collapse; }
        .wpiso-toggle-table tr { border-bottom: 1px solid #f0f0f1; }
        .wpiso-toggle-table tr:last-child { border-bottom: none; }
        .wpiso-toggle-table td { padding: 10px 8px; vertical-align: middle; }
        .wpiso-toggle-cell { width: 50px; text-align: center; }
        .wpiso-option-desc { display: block; color: #646970; font-size: 12px; margin-top: 2px; }

        /* فرم‌ها */
        .wpiso-select { min-width: 250px; padding: 6px 10px; border-radius: 4px; border: 1px solid #8c8f94; }
        .wpiso-input { padding: 6px 10px; border-radius: 4px; border: 1px solid #8c8f94; min-width: 200px; }
        .wpiso-input-inline { min-width: 250px; }
        .wpiso-textarea { width: 100%; font-family: Consolas, monospace; font-size: 13px; padding: 10px; border-radius: 4px; border: 1px solid #8c8f94; direction: ltr; text-align: left; resize: vertical; }
        .wpiso-field { margin-bottom: 12px; }
        .wpiso-field label { display: block; margin-bottom: 4px; font-weight: 600; font-size: 13px; }
        .wpiso-field-row { display: flex; gap: 15px; }
        .wpiso-field-row .wpiso-field { flex: 1; }

        /* Toggle row */
        .wpiso-toggle-row { display: flex; align-items: center; gap: 12px; padding: 8px 0; }

        /* رادیو کارت */
        .wpiso-filter-mode { display: flex; gap: 15px; flex-wrap: wrap; }
        .wpiso-radio-card { flex: 1; min-width: 250px; border: 2px solid #c3c4c7; border-radius: 8px; padding: 15px; cursor: pointer; transition: all .2s; }
        .wpiso-radio-card:hover { border-color: #2271b1; }
        .wpiso-radio-card.active { border-color: #2271b1; background: #f0f6fc; }
        .wpiso-radio-card input { display: none; }
        .wpiso-radio-content strong { font-size: 14px; }
        .wpiso-radio-content p { color: #646970; font-size: 13px; margin: 5px 0 0; }

        /* وضعیت */
        .wpiso-status-msg { font-size: 13px; margin-right: 10px; display: inline-block; }
        .wpiso-status-msg.success { color: #00a32a; }
        .wpiso-status-msg.error { color: #d63638; }
        .wpiso-badge { display: inline-block; padding: 2px 8px; border-radius: 10px; font-size: 11px; font-weight: 600; }
        .wpiso-badge-red { background: #fcedea; color: #d63638; }
        .wpiso-badge-green { background: #edfaef; color: #00a32a; }
        .wpiso-empty { color: #646970; font-style: italic; }

        /* لیست */
        .wpiso-list { list-style: none; padding: 0; margin: 0; }
        .wpiso-list li { padding: 6px 0; border-bottom: 1px solid #f0f0f1; font-size: 13px; }

        /* پریست‌ها */
        .wpiso-whitelist-presets { margin-top: 12px; padding-top: 12px; border-top: 1px solid #f0f0f1; }
        .wpiso-whitelist-presets .button { margin: 3px 0 3px 5px; font-size: 12px; }

        /* ابزار تست */
        .wpiso-domain-tools { margin-top: 12px; padding-top: 12px; border-top: 1px solid #f0f0f1; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }

        /* پیش‌نمایش فونت */
        .wpiso-font-preview { background: #f6f7f7; border: 1px solid #dcdcde; border-radius: 6px; padding: 20px; }
        .wpiso-font-preview .preview-fa { font-size: 22px; margin: 0 0 8px; }
        .wpiso-font-preview .preview-en { font-size: 16px; color: #646970; margin: 0; }

        /* آپلود */
        .wpiso-upload-form { background: #f9f9f9; border: 1px dashed #c3c4c7; border-radius: 6px; padding: 15px; }

        /* نوار ذخیره */
        .wpiso-save-bar { position: sticky; bottom: 0; background: #fff; border-top: 1px solid #c3c4c7; padding: 15px 0; text-align: center; z-index: 100; margin-top: 20px; display: flex; align-items: center; justify-content: center; gap: 15px; }

        /* فرم تیبل */
        .wpiso-form-table th { text-align: right; padding: 12px 0; font-weight: 600; white-space: nowrap; width: 180px; }
        .wpiso-form-table td { padding: 12px 15px; }

        @media (max-width: 782px) {
            .wpiso-cards-row { flex-direction: column; }
            .wpiso-card { min-width: 100%; }
            .wpiso-tabs { overflow-x: auto; }
            .wpiso-field-row { flex-direction: column; }
        }
        ';
    }

    /**
     * نوتیس در صفحه پلاگین‌ها
     */
    public function show_notice() {
        $screen = get_current_screen();
        if (!$screen || $screen->id !== 'plugins') return;
        ?>
        <div class="notice notice-success is-dismissible">
            <p>
                <strong>⚡ بهینه‌ساز سرعت ایران v<?php echo esc_html(WPISO_VERSION); ?>:</strong>
                افزونه فعال است — درخواست‌های خارجی مسدود و منابع محلی جایگزین شده‌اند.
                <a href="<?php echo esc_url(admin_url('admin.php?page=wpiso-settings')); ?>">تنظیمات پیشرفته</a>
            </p>
        </div>
        <?php
    }
}
