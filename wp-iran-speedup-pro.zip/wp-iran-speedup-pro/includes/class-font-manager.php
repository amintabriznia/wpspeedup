<?php
/**
 * Font Manager v4.2.0
 *
 * مدیریت فونت‌های سفارشی — آپلود، انتخاب و اعمال فونت دلخواه
 * ✅ فونت‌های پیش‌فرض فارسی با URL واقعی CDN
 * ✅ سلکتور هوشمند — آیکون‌فونت‌ها محافظت می‌شوند
 * ✅ دانلود خودکار فونت به سرور محلی
 *
 * @package WPISO
 * @since   4.2.0
 */

if (!defined('ABSPATH')) exit;

class WPISO_Font_Manager {
    private static $instance = null;

    /** @var array فونت‌های پیش‌فرض فارسی با URL واقعی */
    private $builtin_fonts = [];

    /**
     * کلاس‌های آیکون‌فونت که باید از تغییر font-family مستثنی شوند
     * @var array
     */
    private $icon_exclusions = [
        // Font Awesome
        '.fa', '.fas', '.far', '.fal', '.fab', '.fad', '.fass','.ab-icon',
        '.fa-solid', '.fa-regular', '.fa-light', '.fa-brands', '.fa-duotone',
        '[class^="fa-"]', '[class*=" fa-"]',

        // Elementor Icons
        '.eicon', '[class^="eicon-"]', '[class*=" eicon-"]',

        // Dashicons (وردپرس)
        '.dashicons', '.dashicons-before', '[class^="dashicons-"]', '[class*=" dashicons-"]',

        // Genericons
        '.genericon', '[class^="genericon-"]',

        // Material Icons
        '.material-icons', '.material-icons-round', '.material-icons-outlined',
        '.material-icons-sharp', '.material-icons-two-tone',

        // IcoMoon
        '[class^="icon-"]', '[class*=" icon-"]',

        // WooCommerce
        '.woocommerce-Price-currencySymbol',

        // Simple Line Icons
        '[class^="sl-"]', '[class*=" sl-"]',

        // Themify Icons
        '[class^="ti-"]', '[class*=" ti-"]',

        // ET Line Icons (Divi)
        '[class^="et-"]', '[class*=" et-"]',
    ];

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->setup_builtin_fonts();
        $this->register_hooks();
    }

/**
 * فونت‌های پیش‌فرض فارسی از مسیر محلی
 */
private function setup_builtin_fonts() {

    $base = plugin_dir_url(dirname(__FILE__)) . 'assets/webfonts/';

    $this->builtin_fonts = [

        'vazirmatn' => [
            'name'  => 'Vazirmatn',
            'label' => 'وزیرمتن',
            'weights' => [
                '100' => $base . 'vazirmatn/Vazirmatn-Thin.woff2',
                '200' => $base . 'vazirmatn/Vazirmatn-ExtraLight.woff2',
                '300' => $base . 'vazirmatn/Vazirmatn-Light.woff2',
                '400' => $base . 'vazirmatn/Vazirmatn-Regular.woff2',
                '500' => $base . 'vazirmatn/Vazirmatn-Medium.woff2',
                '600' => $base . 'vazirmatn/Vazirmatn-SemiBold.woff2',
                '700' => $base . 'vazirmatn/Vazirmatn-Bold.woff2',
                '800' => $base . 'vazirmatn/Vazirmatn-ExtraBold.woff2',
                '900' => $base . 'vazirmatn/Vazirmatn-Black.woff2',
            ],
            'type' => 'persian',
        ],

        'sahel' => [
            'name'  => 'Sahel',
            'label' => 'ساحل',
            'weights' => [
                '300' => $base . 'sahel/Sahel-Light.woff2',
                '400' => $base . 'sahel/Sahel-Regular.woff2',
                '600' => $base . 'sahel/Sahel-SemiBold.woff2',
                '700' => $base . 'sahel/Sahel-Bold.woff2',
                '900' => $base . 'sahel/Sahel-Black.woff2',
            ],
            'type' => 'persian',
        ],

        // ⚠️ فونت‌های زیر فعلاً غیرفعال هستند — فایل‌های woff2 در پوشه assets/webfonts موجود نیست
        // برای فعال‌سازی، ابتدا فایل‌های فونت را در پوشه مربوطه قرار دهید
        /*
        'shabnam' => [
            'name'  => 'Shabnam',
            'label' => 'شبنم',
            'weights' => [
                '200' => $base . 'shabnam/Shabnam-Thin.woff2',
                '300' => $base . 'shabnam/Shabnam-Light.woff2',
                '400' => $base . 'shabnam/Shabnam.woff2',
                '500' => $base . 'shabnam/Shabnam-Medium.woff2',
                '700' => $base . 'shabnam/Shabnam-Bold.woff2',
            ],
            'type' => 'persian',
        ],

        'samim' => [
            'name'  => 'Samim',
            'label' => 'صمیم',
            'weights' => [
                '300' => $base . 'samim/Samim-Light.woff2',
                '400' => $base . 'samim/Samim.woff2',
                '500' => $base . 'samim/Samim-Medium.woff2',
                '700' => $base . 'samim/Samim-Bold.woff2',
            ],
            'type' => 'persian',
        ],

        'tanha' => [
            'name'  => 'Tanha',
            'label' => 'تنها',
            'weights' => [
                '300' => $base . 'tanha/Tanha-Light.woff2',
                '400' => $base . 'tanha/Tanha.woff2',
                '500' => $base . 'tanha/Tanha-Medium.woff2',
                '700' => $base . 'tanha/Tanha-Bold.woff2',
            ],
            'type' => 'persian',
        ],

        'estedad' => [
            'name'  => 'Estedad',
            'label' => 'استعداد',
            'weights' => [
                '100' => $base . 'estedad/Estedad-Thin.woff2',
                '200' => $base . 'estedad/Estedad-ExtraLight.woff2',
                '300' => $base . 'estedad/Estedad-Light.woff2',
                '400' => $base . 'estedad/Estedad-Regular.woff2',
                '500' => $base . 'estedad/Estedad-Medium.woff2',
                '600' => $base . 'estedad/Estedad-SemiBold.woff2',
                '700' => $base . 'estedad/Estedad-Bold.woff2',
                '800' => $base . 'estedad/Estedad-ExtraBold.woff2',
                '900' => $base . 'estedad/Estedad-Black.woff2',
            ],
            'type' => 'persian',
        ],
        */

    ];
}

    private function register_hooks() {
        $settings = get_option('wpiso_settings', []);

        if (!empty($settings['custom_font_enabled']) && !empty($settings['custom_font_name'])) {
            add_action('wp_head', [$this, 'inject_font_face'], 1);
            add_action('wp_head', [$this, 'inject_font_styles'], 2);
            // در ادمین هم اعمال شود (برای پیش‌نمایش)
            add_action('admin_head', [$this, 'inject_font_face'], 1);
        }

        // AJAX برای دانلود فونت به سرور
        add_action('wp_ajax_wpiso_download_builtin_font', [$this, 'ajax_download_builtin_font']);
    }

    /* ═══════════════════════════════════════════════════════════════
     *  تولید @font-face
     * ═══════════════════════════════════════════════════════════════ */

    public function inject_font_face() {
        $settings = get_option('wpiso_settings', []);
        $font_name = $settings['custom_font_name'] ?? '';
        $font_display = $settings['font_display'] ?? 'swap';

        if (empty($font_name)) return;

        $css = '<style id="wpiso-custom-fonts">' . "\n";

        // ابتدا بررسی فونت‌های آپلود شده
        $custom_fonts = get_option('wpiso_custom_fonts', []);
        $font_files = [];
        foreach ($custom_fonts as $font) {
            if ($font['name'] === $font_name) {
                $font_files[] = $font;
            }
        }

        if (!empty($font_files)) {
            // === فونت آپلود شده ===
            foreach ($font_files as $font) {
                $format = $this->get_font_format($font['format']);
                $css .= $this->build_font_face(
                    $font_name,
                    esc_url($font['url']),
                    $format,
                    $font['weight'],
                    $font['style'],
                    $font_display
                );
            }
        } else {
            // === فونت پیش‌فرض ===
            $builtin_key = $this->find_builtin_font($font_name);
            if ($builtin_key) {
                $builtin = $this->builtin_fonts[$builtin_key];
                $selected_weight = $settings['custom_font_weight'] ?? '400';

                // بررسی آیا فایل محلی موجود است
                $local_file = $this->get_local_font_path($builtin_key, $selected_weight);
                $local_url  = $this->get_local_font_url($builtin_key, $selected_weight);

                if (file_exists($local_file)) {
                    // فایل محلی موجود — از آن استفاده کن
                    $css .= $this->build_font_face(
                        $builtin['name'], $local_url, 'woff2',
                        $selected_weight, 'normal', $font_display
                    );
                } elseif (isset($builtin['weights'][$selected_weight])) {
                    // از CDN مستقیم لود کن
                    $cdn_url = $builtin['weights'][$selected_weight];
                    $css .= $this->build_font_face(
                        $builtin['name'], $cdn_url, 'woff2',
                        $selected_weight, 'normal', $font_display
                    );
                }

                // وزن‌های اضافی رایج هم لود شوند (400 + 700)
                $extra_weights = $this->get_essential_weights($selected_weight);
                foreach ($extra_weights as $ew) {
                    if ($ew === $selected_weight) continue;
                    if (!isset($builtin['weights'][$ew])) continue;

                    $ew_local = $this->get_local_font_path($builtin_key, $ew);
                    $ew_url   = $this->get_local_font_url($builtin_key, $ew);

                    if (file_exists($ew_local)) {
                        $css .= $this->build_font_face(
                            $builtin['name'], $ew_url, 'woff2',
                            $ew, 'normal', $font_display
                        );
                    } elseif (isset($builtin['weights'][$ew])) {
                        $css .= $this->build_font_face(
                            $builtin['name'], $builtin['weights'][$ew], 'woff2',
                            $ew, 'normal', $font_display
                        );
                    }
                }
            }
        }

        $css .= '</style>' . "\n";
        echo $css;
    }

    /**
     * ساخت یک بلوک @font-face
     */
    private function build_font_face($family, $url, $format, $weight, $style, $display) {
        return "@font-face {\n"
            . "  font-family: '{$family}';\n"
            . "  src: url('{$url}') format('{$format}');\n"
            . "  font-weight: {$weight};\n"
            . "  font-style: {$style};\n"
            . "  font-display: {$display};\n"
            . "}\n";
    }

    /**
     * وزن‌های ضروری — همیشه Regular و Bold لود شوند
     */
    private function get_essential_weights($selected) {
        $essentials = ['400', '700'];
        if (!in_array($selected, $essentials)) {
            $essentials[] = $selected;
        }
        return array_unique($essentials);
    }

    /* ═══════════════════════════════════════════════════════════════
     *  اعمال فونت با محافظت آیکون‌ها
     *  ✅ سلکتور هوشمند — آیکون‌فونت‌ها exclude می‌شوند
     * ═══════════════════════════════════════════════════════════════ */

    public function inject_font_styles() {
        $settings = get_option('wpiso_settings', []);
        $font_name = $settings['custom_font_name'] ?? '';
        $target = $settings['custom_font_target'] ?? 'body';

        if (empty($font_name)) return;

        // اگر فونت built-in است، نام واقعی‌اش را پیدا کن
        $builtin_key = $this->find_builtin_font($font_name);
        if ($builtin_key) {
            $font_name = $this->builtin_fonts[$builtin_key]['name'];
        }

        $font_family = "'{$font_name}', Tahoma, Arial, sans-serif";

        // ساخت :not() سلکتور برای محافظت آیکون‌ها
        $not_selector = $this->build_icon_exclusion();

        $css = '<style id="wpiso-font-apply">' . "\n";

        switch ($target) {
            case 'body':
                $css .= "body { font-family: {$font_family} !important; }\n";
                // اعمال روی عناصر متنی — بدون آیکون‌ها
                $css .= $this->get_text_elements_selector($not_selector, $font_family);
                break;

            case 'headings':
                $css .= "h1{$not_selector}, h2{$not_selector}, h3{$not_selector}, h4{$not_selector}, h5{$not_selector}, h6{$not_selector} { font-family: {$font_family} !important; }\n";
                break;

            case 'both':
                $css .= "body { font-family: {$font_family} !important; }\n";
                $css .= $this->get_text_elements_selector($not_selector, $font_family);
                $css .= "h1{$not_selector}, h2{$not_selector}, h3{$not_selector}, h4{$not_selector}, h5{$not_selector}, h6{$not_selector} { font-family: {$font_family} !important; }\n";
                break;

            case 'custom':
                $custom_selector = sanitize_text_field($settings['custom_font_selector'] ?? 'body');
                $css .= "{$custom_selector} { font-family: {$font_family} !important; }\n";
                break;
        }

        $css .= '</style>' . "\n";
        echo $css;
    }

    /**
     * ساخت :not() سلکتور برای محافظت آیکون‌فونت‌ها
     * خروجی مثال: :not(.fa):not(.fas):not(.dashicons):not([class^="eicon-"])
     */
    private function build_icon_exclusion() {
        $parts = [];
        foreach ($this->icon_exclusions as $sel) {
            $parts[] = ':not(' . $sel . ')';
        }
        return implode('', $parts);
    }

    /**
     * سلکتور عناصر متنی (بدون * که آیکون‌ها را خراب می‌کند)
     * بجای body * از لیست مشخص عناصر متنی استفاده می‌شود
     */
    private function get_text_elements_selector($not, $font_family) {
        $text_elements = [
            'p', 'span', 'a', 'li', 'td', 'th', 'label',
            'input', 'textarea', 'select', 'button',
            'blockquote', 'figcaption', 'cite',
            'div', 'section', 'article', 'aside', 'nav', 'footer', 'header', 'main',
            'strong', 'em', 'b', 'i' . $not, // i بدون آیکون‌ها
            'small', 'mark', 'del', 'ins', 'sub', 'sup',
            'dt', 'dd', 'caption', 'legend',
        ];

        // اعمال :not() فقط روی عناصری که ممکن است آیکون باشند
        $icon_risk_elements = ['i', 'span', 'a'];

        $selectors = [];
        foreach ($text_elements as $el) {
            // اگر قبلاً :not دارد (مثل 'i:not(...)') اضافه نکن
            if (strpos($el, ':not') !== false) {
                $selectors[] = $el;
                continue;
            }

            if (in_array($el, $icon_risk_elements)) {
                $selectors[] = $el . $not;
            } else {
                $selectors[] = $el;
            }
        }

        return implode(",\n", $selectors) . " { font-family: {$font_family} !important; }\n";
    }

    /* ═══════════════════════════════════════════════════════════════
     *  مسیرهای محلی فونت
     * ═══════════════════════════════════════════════════════════════ */

    private function get_local_font_dir() {
        $upload_dir = wp_upload_dir();
        return $upload_dir['basedir'] . '/wpiso-fonts/builtin/';
    }

    private function get_local_font_url_base() {
        $upload_dir = wp_upload_dir();
        return $upload_dir['baseurl'] . '/wpiso-fonts/builtin/';
    }

    private function get_local_font_path($font_key, $weight) {
        return $this->get_local_font_dir() . "{$font_key}-{$weight}.woff2";
    }

    private function get_local_font_url($font_key, $weight) {
        return $this->get_local_font_url_base() . "{$font_key}-{$weight}.woff2";
    }

    /* ═══════════════════════════════════════════════════════════════
     *  دانلود خودکار فونت از CDN به سرور محلی
     * ═══════════════════════════════════════════════════════════════ */

    public function ajax_download_builtin_font() {
        check_ajax_referer('wpiso_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('دسترسی ندارید.');
        }

        $font_key = sanitize_text_field($_POST['font_key'] ?? '');
        $weight   = sanitize_text_field($_POST['weight'] ?? '400');

        if (!isset($this->builtin_fonts[$font_key])) {
            wp_send_json_error('فونت یافت نشد.');
        }

        $font = $this->builtin_fonts[$font_key];
        if (!isset($font['weights'][$weight])) {
            wp_send_json_error("وزن {$weight} برای این فونت موجود نیست.");
        }

        $cdn_url = $font['weights'][$weight];
        $local_dir = $this->get_local_font_dir();
        $local_file = $this->get_local_font_path($font_key, $weight);

        // ساخت پوشه
        if (!file_exists($local_dir)) {
            wp_mkdir_p($local_dir);
        }

        // دانلود
        $response = wp_remote_get($cdn_url, ['timeout' => 30, 'sslverify' => false]);
        if (is_wp_error($response)) {
            wp_send_json_error('خطا در دانلود: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            wp_send_json_error("خطای HTTP {$code} در دانلود فونت.");
        }

        $body = wp_remote_retrieve_body($response);
        if (empty($body) || strlen($body) < 1000) {
            wp_send_json_error('فایل دانلود شده خالی یا معیوب است.');
        }

        // ذخیره
        $saved = file_put_contents($local_file, $body);
        if (!$saved) {
            wp_send_json_error('خطا در ذخیره فایل. مجوزهای پوشه را بررسی کنید.');
        }

        wp_send_json_success([
            'message'  => sprintf('فونت %s (وزن %s) با موفقیت دانلود شد.', $font['label'], $weight),
            'file'     => basename($local_file),
            'size'     => size_format($saved),
            'local_url'=> $this->get_local_font_url($font_key, $weight),
        ]);
    }

    /**
     * دانلود تمام وزن‌های یک فونت
     */
    public function download_all_weights($font_key) {
        if (!isset($this->builtin_fonts[$font_key])) return false;

        $font = $this->builtin_fonts[$font_key];
        $results = [];

        foreach ($font['weights'] as $weight => $url) {
            $local_file = $this->get_local_font_path($font_key, $weight);

            if (file_exists($local_file)) {
                $results[$weight] = 'exists';
                continue;
            }

            $response = wp_remote_get($url, ['timeout' => 30, 'sslverify' => false]);
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
                $results[$weight] = 'failed';
                continue;
            }

            $local_dir = $this->get_local_font_dir();
            if (!file_exists($local_dir)) wp_mkdir_p($local_dir);

            file_put_contents($local_file, wp_remote_retrieve_body($response));
            $results[$weight] = 'downloaded';
        }

        return $results;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  وضعیت فونت‌های محلی (برای نمایش در ادمین)
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * بررسی وضعیت دانلود فونت‌های پیش‌فرض
     */
    public function get_builtin_font_status($font_key) {
        if (!isset($this->builtin_fonts[$font_key])) return [];

        $font = $this->builtin_fonts[$font_key];
        $status = [];

        foreach ($font['weights'] as $weight => $url) {
            $local_file = $this->get_local_font_path($font_key, $weight);
            $status[$weight] = [
                'local_exists' => file_exists($local_file),
                'local_size'   => file_exists($local_file) ? size_format(filesize($local_file)) : null,
                'cdn_url'      => $url,
            ];
        }

        return $status;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  Helper متدها
     * ═══════════════════════════════════════════════════════════════ */

    private function get_font_format($ext) {
        $formats = [
            'woff2' => 'woff2',
            'woff'  => 'woff',
            'ttf'   => 'truetype',
            'otf'   => 'opentype',
            'eot'   => 'embedded-opentype',
            'svg'   => 'svg',
        ];
        return $formats[$ext] ?? 'woff2';
    }

    private function find_builtin_font($name) {
        foreach ($this->builtin_fonts as $key => $font) {
            if (strtolower($font['name']) === strtolower($name) || $font['label'] === $name) {
                return $key;
            }
        }
        return null;
    }

    public function get_builtin_fonts() {
        return $this->builtin_fonts;
    }

    public static function get_uploaded_fonts() {
        $fonts = get_option('wpiso_custom_fonts', []);
        $grouped = [];
        foreach ($fonts as $id => $font) {
            $name = $font['name'];
            if (!isset($grouped[$name])) {
                $grouped[$name] = [
                    'name'  => $name,
                    'files' => [],
                ];
            }
            $font['id'] = $id;
            $grouped[$name]['files'][] = $font;
        }
        return $grouped;
    }
}
