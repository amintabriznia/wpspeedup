<?php
/**
 * Performance Optimizer v4.0.0
 *
 * بهینه‌سازی عملکرد وردپرس — حذف bloat و کاهش درخواست‌های خارجی
 *
 * @package WPISO
 * @since   3.0.0
 */

if (!defined('ABSPATH')) exit;

class WPISO_Performance_Optimizer {
    private static $instance = null;

    /** @var array تنظیمات افزونه */
    private $settings = [];

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->settings = get_option('wpiso_settings', []);

        if (!empty($this->settings['optimize_updates'])) {
            $this->optimize_updates();
        }
        $this->optimize_http_requests();
        if (!empty($this->settings['disable_emoji']) || !empty($this->settings['disable_embeds']) || !empty($this->settings['disable_xmlrpc'])) {
            $this->remove_bloat();
        }
        $this->disable_external_services();
    }

    /* ═══════════════════════════════════════════════════════════════
     *  مدیریت آپدیت‌ها
     * ═══════════════════════════════════════════════════════════════ */

    private function optimize_updates() {
        // غیرفعال کردن بررسی خودکار آپدیت (تایم‌اوت‌های طولانی در ایران)
        add_filter('pre_site_transient_update_core',    [$this, 'block_update_check']);
        add_filter('pre_site_transient_update_plugins', [$this, 'block_update_check']);
        add_filter('pre_site_transient_update_themes',  [$this, 'block_update_check']);

        // غیرفعال کردن auto-update cron
        add_filter('automatic_updater_disabled', '__return_true');

        // ✅ مسدودسازی مستقیم درخواست‌های HTTP آپدیت
        // حتی اگر transient خالی شود، درخواست HTTP ارسال نشود
        add_filter('pre_http_request', [$this, 'block_update_http_requests'], 1, 3);

        // ✅ غیرفعال کردن cron‌های آپدیت
        add_action('init', function() {
            wp_clear_scheduled_hook('wp_update_plugins');
            wp_clear_scheduled_hook('wp_update_themes');
            wp_clear_scheduled_hook('wp_version_check');
        });

        // کاهش Revisions
        if (!defined('WP_POST_REVISIONS')) {
            define('WP_POST_REVISIONS', 3);
        }
    }

    /**
     * مسدودسازی درخواست‌های HTTP آپدیت به api.wordpress.org
     * ✅ جلوگیری از timeout در شرایط فیلترینگ
     */
    public function block_update_http_requests($preempt, $args, $url) {
        if (!is_string($url)) return $preempt;

        // فقط مسیرهای آپدیت مسدود شوند — نه کل api.wordpress.org
        $blocked_paths = [
            'api.wordpress.org/plugins/update-check',
            'api.wordpress.org/themes/update-check',
            'api.wordpress.org/core/version-check',
            'api.wordpress.org/translations',
        ];

        foreach ($blocked_paths as $path) {
            if (strpos($url, $path) !== false) {
                return new WP_Error(
                    'wpiso_update_blocked',
                    sprintf('[WPISO] درخواست آپدیت به %s مسدود شد.', esc_url_raw($url))
                );
            }
        }

        return $preempt;
    }

    /**
     * برگرداندن یک آبجکت خالی بجای null
     * (null باعث می‌شود وردپرس دوباره تلاش کند)
     */
    public function block_update_check($transient) {
        // اگر قبلاً مقداری دارد، همان را برگردان
        if (!empty($transient)) return $transient;

        // یک آبجکت خالی برای جلوگیری از درخواست مجدد
        $obj = new stdClass();
        $obj->last_checked = time();
        $obj->version_checked = get_bloginfo('version');
        $obj->updates = [];
        $obj->translations = [];
        $obj->response = [];
        $obj->no_update = [];
        return $obj;
    }

    /* ═══════════════════════════════════════════════════════════════
     *  بهینه‌سازی درخواست‌های HTTP
     * ═══════════════════════════════════════════════════════════════ */

    private function optimize_http_requests() {
        // تایم‌اوت کوتاه‌تر برای درخواست‌های خارجی
        add_filter('http_request_timeout', function($timeout) {
            return min($timeout, 5); // حداکثر ۵ ثانیه
        });

        // محدودکردن redirectها
        add_filter('http_request_redirection_count', function() {
            return 2;
        });

        // بهینه‌سازی args — فقط timeout و redirect
        // ⚠️ اشکال مهم نسخه قبلی: blocking=false روی همه درخواست‌ها
        //    باعث می‌شد پاسخ‌های ضروری (مثل WooCommerce API) نادیده گرفته شود
        add_filter('http_request_args', function($args, $url) {
            // فقط برای درخواست‌های غیرضروری timeout کوتاه اعمال شود
            $host = parse_url($url, PHP_URL_HOST);

            $non_essential_hosts = [
                'api.wordpress.org',
                'downloads.wordpress.org',
                'planet.wordpress.org',
            ];

            if (in_array($host, $non_essential_hosts, true)) {
                $args['timeout'] = 3;
                $args['redirection'] = 2;
            }

            return $args;
        }, 10, 2);

        // Heartbeat — فقط در صفحه ویرایش پست فعال بماند (شرطی)
        if (!empty($this->settings['disable_heartbeat'])) {
            add_action('init', function() {
                if (is_admin()) {
                    global $pagenow;
                    // در post editor نیاز به Heartbeat برای auto-save داریم
                    if (!in_array($pagenow, ['post.php', 'post-new.php'], true)) {
                        wp_deregister_script('heartbeat');
                        // ✅ wp-auth-check به heartbeat وابسته است — باید همراه آن حذف شود
                        wp_deregister_script('wp-auth-check');
                    }
                } else {
                    // در فرانت‌اند Heartbeat لازم نیست
                    wp_deregister_script('heartbeat');
                    wp_deregister_script('wp-auth-check');
                }
            }, 1);
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  حذف Bloat
     * ═══════════════════════════════════════════════════════════════ */

    private function remove_bloat() {
        // ── Emoji ── (شرطی)
        if (!empty($this->settings['disable_emoji'])) {
            remove_action('wp_head',           'print_emoji_detection_script', 7);
            remove_action('admin_print_scripts','print_emoji_detection_script');
            remove_action('wp_print_styles',   'print_emoji_styles');
            remove_action('admin_print_styles','print_emoji_styles');
            remove_filter('the_content_feed',  'wp_staticize_emoji');
            remove_filter('comment_text_rss',  'wp_staticize_emoji');
            remove_filter('wp_mail',           'wp_staticize_emoji_for_email');
            add_filter('emoji_svg_url',        '__return_false');
        }

        // ── Embeds ── (شرطی)
        if (!empty($this->settings['disable_embeds'])) {
            add_action('init', function() {
                remove_action('wp_head',      'wp_oembed_add_discovery_links');
                remove_action('wp_head',      'wp_oembed_add_host_js');
                remove_action('rest_api_init','wp_oembed_register_route');
                remove_filter('oembed_dataparse','wp_filter_oembed_result', 10);
            });
        }

        // ── Head cleanup ── (همیشه فعال — بدون ضرر)
        remove_action('wp_head', 'rsd_link');
        remove_action('wp_head', 'wlwmanifest_link');
        remove_action('wp_head', 'wp_generator');
        remove_action('wp_head', 'wp_shortlink_wp_head');
        remove_action('wp_head', 'rest_output_link_wp_head');
        remove_action('wp_head', 'feed_links_extra', 3);
        remove_action('template_redirect', 'rest_output_link_header', 11);

        // ── XML-RPC ── (شرطی)
        if (!empty($this->settings['disable_xmlrpc'])) {
            add_filter('xmlrpc_enabled', '__return_false');
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     *  غیرفعال کردن سرویس‌های خارجی
     * ═══════════════════════════════════════════════════════════════ */

    private function disable_external_services() {
        // WooCommerce — غیرفعال کردن SkyVerge tracking، marketplace suggestions
        add_filter('woocommerce_allow_marketplace_suggestions', '__return_false');
        add_filter('woocommerce_helper_suppress_admin_notices', '__return_true');

        // Elementor — فقط غیرفعال کردن usage tracking
        // ⚠️ library.elementor.com نباید مسدود شود — برای وارد کردن قالب لازم است
        add_filter('elementor/tracker/send_tracking_data_enable', '__return_false');
        add_action('init', function() {
            if (defined('ELEMENTOR_VERSION')) {
                add_filter('pre_http_request', function($preempt, $args, $url) {
                    // فقط tracking مسدود شود — نه library
                    if (strpos($url, 'my.elementor.com/api/v1/collect') !== false ||
                        strpos($url, 'my.elementor.com/api/v1/feedback') !== false) {
                        return new WP_Error('wpiso_blocked', '[WPISO] Elementor tracking blocked.');
                    }
                    return $preempt;
                }, 5, 3);
            }
        });

        // WP.com — قطع ارتباط Jetpack Site Health
        add_filter('jetpack_just_in_time_msgs', '__return_false');
        add_filter('jetpack_show_promotions',   '__return_false');
    }
}
