<?php
/**
 * Plugin Name: WP Iran Speed Optimizer Pro
 * Plugin URI: https://github.com/amintabriznia
 * Description: بهینه‌ساز پیشرفته سرعت وردپرس برای شرایط فیلترینگ ایران — مسدودسازی درخواست‌های خارجی، مدیریت فونت دلخواه، وایت‌لیست و بلک‌لیست پیشرفته، سرو محلی فونت‌ها و اسکریپت‌ها
 * Version: 4.2.0
 * Author: AMIN TABRIZNIA
 * Text Domain: wpiso
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

define('WPISO_VERSION', '4.2.0');
define('WPISO_PATH', plugin_dir_path(__FILE__));
define('WPISO_URL', plugin_dir_url(__FILE__));
define('WPISO_BASENAME', plugin_basename(__FILE__));

require_once WPISO_PATH . 'includes/class-core.php';

register_activation_hook(__FILE__, ['WPISO_Core', 'activate']);
register_deactivation_hook(__FILE__, ['WPISO_Core', 'deactivate']);

WPISO_Core::init();
