<?php
/**
 * Uninstall — پاکسازی کامل هنگام حذف افزونه
 *
 * @package WPISO
 * @since   4.0.0
 */

if (!defined('WP_UNINSTALL_PLUGIN')) exit;

// حذف تنظیمات
delete_option('wpiso_version');
delete_option('wpiso_settings');
delete_option('wpiso_custom_blocked_domains');
delete_option('wpiso_whitelisted_domains');
delete_option('wpiso_custom_fonts');
delete_option('wpiso_request_log');

// حذف transient
delete_transient('wpiso_status_cache');
delete_transient('wpiso_domain_test_cache');

// حذف پوشه فونت‌ها (اختیاری)
$upload_dir = wp_upload_dir();
$font_dir = $upload_dir['basedir'] . '/wpiso-fonts';
if (is_dir($font_dir)) {
    $files = glob($font_dir . '/*');
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file);
        }
    }
    rmdir($font_dir);
}
